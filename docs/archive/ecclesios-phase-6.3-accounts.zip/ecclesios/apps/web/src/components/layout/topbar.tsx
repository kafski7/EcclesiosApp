import { Bell, Menu, Search } from "lucide-react";
import { badgeCount } from "@ecclesios/shared/domain";
import { Link } from "react-router-dom";
import { useUnread } from "@/lib/account";
import { useMe } from "@/lib/me";
import { useSession } from "@/stores/session";
import { useUi } from "@/stores/ui";

/** Kit .topbar: hamburger (≤980px), search, notifications and account. */
export function Topbar() {
  const { navOpen, setNavOpen } = useUi();
  const principal = useSession((s) => s.principal);
  const unread = badgeCount(useUnread().data?.unread ?? 0);
  const me = useMe();

  return (
    <header className="topbar">
      <button
        type="button"
        className="hamburger"
        aria-label="Open menu"
        aria-controls="app-sidebar"
        aria-expanded={navOpen}
        onClick={() => setNavOpen(true)}
      >
        <Menu className="ic" />
      </button>

      {/* One app-wide search → a results page across every section: Phase 9 (todo "Global search"). */}
      <form className="search" role="search" onSubmit={(e) => e.preventDefault()}>
        <Search className="ic" aria-hidden />
        <input type="search" placeholder="Search readings, saints, hymns…" aria-label="Search" />
      </form>

      <div className="top-actions">
        <Link to="/notifications" className="icon-btn" aria-label={unread ? `Notifications, ${unread} unread` : "Notifications"}>
          <Bell className="ic" />
          {unread ? <i className="dot-badge">{unread}</i> : null}
        </Link>
        {principal ? (
          <Link to="/account" className="avatar av-36 av-brand" title="Your account" aria-label="Your account">
            {me.data ? `${me.data.firstName[0] ?? ""}${me.data.lastName[0] ?? ""}` : "•"}
          </Link>
        ) : (
          <Link to="/login" className="btn btn-primary btn-sm">
            Sign in
          </Link>
        )}
      </div>
    </header>
  );
}
