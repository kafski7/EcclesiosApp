# @ecclesios/db

Placeholder. Drizzle ORM + drizzle-kit are set up in **Phase 1** (see `docs/todo.md`).
