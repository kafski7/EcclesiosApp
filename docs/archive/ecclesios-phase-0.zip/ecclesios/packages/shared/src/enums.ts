import { z } from "zod";

/**
 * Operating hierarchy for this deployment (blueprint §3), top → bottom.
 * NUNCIATURE and VATICAN exist in the data model but are out of scope for
 * operations — they are kept here so the DB enum and the TS type never drift.
 */
export const HIERARCHY_LEVELS = [
  "VATICAN",
  "NUNCIATURE",
  "PROVINCE",
  "ARCHDIOCESE",
  "DIOCESE",
  "DEANERY",
  "PARISH",
  "OUTSTATION",
] as const;
export const HierarchyLevelSchema = z.enum(HIERARCHY_LEVELS);
export type HierarchyLevel = z.infer<typeof HierarchyLevelSchema>;

/** Levels a CMS group may actually operate at in this deployment. */
export const OPERATIONAL_LEVELS: readonly HierarchyLevel[] = [
  "PROVINCE",
  "ARCHDIOCESE",
  "DIOCESE",
  "DEANERY",
  "PARISH",
  "OUTSTATION",
];

/** Church (members-table) roles — functionality §1. Super-Admin lives in `users`, not here. */
export const MEMBER_ROLES = ["ADMINISTRATOR", "MANAGER", "SOCIETY_LEADER", "PARISHIONER"] as const;
export const MemberRoleSchema = z.enum(MEMBER_ROLES);
export type MemberRole = z.infer<typeof MemberRoleSchema>;

/** Platform (users-table) roles. */
export const PLATFORM_ROLES = ["SUPER_ADMIN", "CREATOR"] as const;
export const PlatformRoleSchema = z.enum(PLATFORM_ROLES);
export type PlatformRole = z.infer<typeof PlatformRoleSchema>;

/** Depth helper: lower number = higher in the hierarchy. */
export const levelRank = (level: HierarchyLevel): number => HIERARCHY_LEVELS.indexOf(level);
