# Ecclesios

A social platform for the Catholic Church with an integrated Church Management application.
Greenfield v2 rebuild — see [`docs/blueprint.md`](docs/blueprint.md) and [`docs/functionality.md`](docs/functionality.md).
Build plan: [`docs/todo.md`](docs/todo.md).

## Prerequisites
- Node **22+** (`nvm use`)
- pnpm **9+** (`corepack enable`)
- Docker + Docker Compose

## Setup
```bash
corepack enable
pnpm i
cp apps/api/.env.example apps/api/.env
cp apps/web/.env.example apps/web/.env
cp apps/admin/.env.example apps/admin/.env
docker compose up -d          # postgres 16, redis 7, minio (+ bucket init)
pnpm build                    # builds packages/shared
pnpm dev
```

Verify:
```bash
pnpm typecheck && pnpm test
docker compose ps             # postgres, redis, minio healthy; minio-init exited 0
```

| Service | URL | Dev credentials |
|---|---|---|
| Postgres | `localhost:5432` | ecclesios / ecclesios, db `ecclesios` |
| Redis | `localhost:6379` | — |
| MinIO API | `http://localhost:9000` | ecclesios / ecclesios-dev-secret |
| MinIO console | `http://localhost:9001` | same |

## Workspace layout
```
apps/
  api/      NestJS API                               (Phase 2)
  web/      Social platform — React + Tailwind + shadcn (Phase 3)
  admin/    CMS — React + CoreUI v5                  (Phase 4)
  mobile/   Expo placeholder — not a workspace yet   (Phase 11)
packages/
  shared/   Zod schemas + TS types (API contracts)
  db/       Drizzle schema, migrations, seeds        (Phase 1)
  config/   Shared tsconfig / ESLint / Prettier / Vitest
docs/       Specs — the contract
```

## Scripts
| Command | Does |
|---|---|
| `pnpm dev` | run all apps in watch mode |
| `pnpm build` / `lint` / `typecheck` / `test` | across the workspace via Turborepo |
| `pnpm format` | Prettier write |
| `pnpm infra:up` / `infra:down` / `infra:reset` | Docker services (reset wipes volumes) |

## Conventions
Branching, commits and PRs: [`CONTRIBUTING.md`](CONTRIBUTING.md). Secrets: [`docs/ops/secrets.md`](docs/ops/secrets.md).
