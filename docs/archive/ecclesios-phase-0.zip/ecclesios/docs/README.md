# docs/

Source of truth for Ecclesios. Copy these in from the design folder:

- `blueprint.md` — architecture, stack, schema, RBAC
- `functionality.md` — functional spec per section
- `todo.md` — master build plan
- `hierarchy.md`, `sup_prompt.md`, `prompt.md` — ecclesiastical levels & reference

- `ops/secrets.md` — production secret-management plan (Phase 0)
