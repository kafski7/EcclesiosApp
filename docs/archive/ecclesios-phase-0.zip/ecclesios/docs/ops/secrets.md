# Secret Management Plan

## Principles
1. **No secrets in code or in git.** Only `.env.example` files (with dummy values) are committed.
2. **No `.env` files in deploy artifacts.** Production containers receive secrets as environment variables injected by the host platform at runtime.
3. **Browser apps hold no secrets.** Anything prefixed `VITE_` is public by design.
4. **Least privilege.** Each service gets only the credentials it needs (e.g. the API's S3 key is scoped to the `ecclesios-media` bucket).

## Environments
| Env | Where secrets live |
|---|---|
| Local dev | `apps/*/.env` copied from `.env.example` (git-ignored) |
| CI | GitHub Actions secrets (only what tests need — none at Phase 0) |
| Staging / Prod | Host platform's secret store (e.g. the container host's encrypted env vars, or a vault such as Doppler / AWS Secrets Manager / Azure Key Vault) — chosen in Phase 10 |

## Secret inventory
| Secret | Used by | Rotation |
|---|---|---|
| `DATABASE_URL` | api | on staff change / annually |
| `REDIS_URL` | api (workers) | annually |
| `S3_ACCESS_KEY` / `S3_SECRET_KEY` | api | annually |
| `JWT_ACCESS_SECRET` / `JWT_REFRESH_SECRET` | api | annually; rotation invalidates sessions |
| SMS / email gateway keys | api workers (Phase 7) | per provider policy |
| Accounting API credentials | api (Phase 6) | per provider policy |
| Bible provider key (API.Bible) | api (Phase 5.2) | per provider policy |

## Rules
- Generate JWT secrets with at least 64 random bytes (`openssl rand -base64 64`).
- The API validates required env vars at boot (Zod env schema, Phase 2) and **refuses to start** if any are missing.
- A leaked secret is rotated immediately and the incident noted in the audit log / ops notes.
