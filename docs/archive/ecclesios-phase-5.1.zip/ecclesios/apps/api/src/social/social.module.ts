import { Module } from "@nestjs/common";
import { ReadingsController } from "./readings.controller";
import { ReadingsService } from "./readings.service";

/** Social content (Phase 5): Readings now; Bible, Saints, Hymnal, Podcasts, Teachings, Explore, feed next. */
@Module({
  controllers: [ReadingsController],
  providers: [ReadingsService],
})
export class SocialModule {}
