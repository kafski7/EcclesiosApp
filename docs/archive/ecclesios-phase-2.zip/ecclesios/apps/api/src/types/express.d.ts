import type { Principal } from "@ecclesios/shared";

declare module "express-serve-static-core" {
  interface Request {
    /** Set by JwtAuthGuard on authenticated routes. */
    principal?: Principal;
  }
}
