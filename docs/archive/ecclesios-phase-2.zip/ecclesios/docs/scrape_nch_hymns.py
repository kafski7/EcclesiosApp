"""
Scrape the New Catholic Hymnal (NCH) website and save all hymns to an Excel file,
with each verse in its own column.

HOW TO USE:
1. Install Python 3 if you don't already have it (https://www.python.org/downloads/)
2. Open a terminal / command prompt in the folder where this file is saved
3. Install the required packages by running:
       pip install requests beautifulsoup4 openpyxl
4. Run the script:
       python scrape_nch_hymns.py
5. It will create a file called "NCH_Hymns.xlsx" in the same folder.

The script is polite to the server: it waits briefly between requests and
prints progress as it goes. It will take a while (829 hymns) - be patient!
If it's interrupted, you can adjust START_HYMN below and re-run to continue
from where you left off (it will overwrite the whole file, so consider
saving a copy of the partial file first if you want to preserve earlier data).
"""

import re
import time
import requests
from bs4 import BeautifulSoup
from openpyxl import Workbook
from openpyxl.utils import get_column_letter

BASE_URL = "https://nch.gonlinesites.com/hymn/{}"
START_HYMN = 1
END_HYMN = 829          # NCH has 829 hymns
OUTPUT_FILE = "NCH_Hymns.xlsx"
DELAY_SECONDS = 0.5      # be polite to the server between requests
HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; ParishChoirArchiver/1.0; personal use)"
}


def clean_text(el):
    """Convert a verse-text div (with <br> tags) into clean multi-line text."""
    # Replace <br> tags with newlines before extracting text
    for br in el.find_all("br"):
        br.replace_with("\n")
    return el.get_text().strip()


def scrape_hymn(number):
    """Fetch a single hymn page and return (title, [verse1, verse2, ...])."""
    url = BASE_URL.format(number)
    resp = requests.get(url, headers=HEADERS, timeout=20)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    title_el = soup.select_one(".hymn-detail-title")
    title = title_el.get_text().strip() if title_el else ""

    verses = []
    for block in soup.select(".verse-block"):
        text_el = block.select_one(".verse-text")
        if text_el:
            verses.append(clean_text(text_el))

    return title, verses


def main():
    wb = Workbook()
    ws = wb.active
    ws.title = "NCH Hymns"

    max_verses_seen = 0
    rows = []  # collect rows first so we know the max verse count for headers

    for num in range(START_HYMN, END_HYMN + 1):
        try:
            title, verses = scrape_hymn(num)
            rows.append((num, title, verses))
            max_verses_seen = max(max_verses_seen, len(verses))
            print(f"NCH {num}: '{title}' - {len(verses)} verse(s)")
        except Exception as e:
            print(f"!! Failed on hymn {num}: {e}")
            rows.append((num, "ERROR", []))
        time.sleep(DELAY_SECONDS)

    # Write header row: Hymn Number, Title, Verse 1, Verse 2, ...
    headers = ["Hymn Number", "Title"] + [f"Verse {i+1}" for i in range(max_verses_seen)]
    ws.append(headers)

    # Write data rows
    for num, title, verses in rows:
        row = [num, title] + verses + [""] * (max_verses_seen - len(verses))
        ws.append(row)

    # Widen columns a bit for readability
    ws.column_dimensions["A"].width = 12
    ws.column_dimensions["B"].width = 40
    for i in range(max_verses_seen):
        col_letter = get_column_letter(3 + i)
        ws.column_dimensions[col_letter].width = 45

    # Wrap text in verse columns so multi-line verses display nicely
    from openpyxl.styles import Alignment
    for row in ws.iter_rows(min_row=2, min_col=3, max_col=2 + max_verses_seen):
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")

    wb.save(OUTPUT_FILE)
    print(f"\nDone! Saved {len(rows)} hymns to {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
