import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { BibleProgress } from "@/lib/continue";

/** Reader preferences, remembered on this device (D-023). null translation = use the server default. */
interface BibleState {
  translation: string | null;
  fontScale: number;
  /** The last chapter opened on this device, for Home's Continue row (D-044). */
  lastRead: BibleProgress | null;
  setTranslation: (code: string) => void;
  setLastRead: (p: Omit<BibleProgress, "at">) => void;
  setFontScale: (scale: number) => void;
}

export const useBiblePrefs = create<BibleState>()(
  persist(
    (set) => ({
      translation: null,
      fontScale: 1,
      lastRead: null,
      setTranslation: (translation) => set({ translation }),
      setLastRead: (p) => set({ lastRead: { ...p, at: Date.now() } }),
      setFontScale: (fontScale) => set({ fontScale: Math.min(1.5, Math.max(0.85, fontScale)) }),
    }),
    { name: "ecclesios.bible" },
  ),
);
