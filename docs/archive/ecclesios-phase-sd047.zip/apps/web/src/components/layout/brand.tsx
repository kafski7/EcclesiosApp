import { Link } from "react-router-dom";

/**
 * Sidebar brand: the cropped monstrance favicon and the wordmark (D-047).
 * Burgundy, because the social sidebar is light (D-046) and gold on cream is too faint.
 */
export function Brand({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <Link to="/" className="brand" aria-label="Ecclesios home" onClick={onNavigate}>
      <img src="/ecclesios-favicon-burgundy.png" alt="" className="brand-mark" />
      <span className="brand-name">Ecclesios</span>
    </Link>
  );
}
