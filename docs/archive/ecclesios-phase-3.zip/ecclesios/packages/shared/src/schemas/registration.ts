import { z } from "zod";
import { PasswordSchema } from "./auth.js";

/** functionality §2.4 — the parish picker on the sign-up screen. Public data only. */
export const ParishOptionSchema = z.object({
  id: z.string().uuid(),
  name: z.string(),
  deanery: z.string().nullable(),
  diocese: z.string().nullable(),
});
export type ParishOption = z.infer<typeof ParishOptionSchema>;

export const ParishSearchQuerySchema = z.object({
  q: z.string().trim().max(100).default(""),
});
export const ParishSearchResponseSchema = z.object({ items: z.array(ParishOptionSchema) });
export type ParishSearchResponse = z.infer<typeof ParishSearchResponseSchema>;

const name = z.string().trim().min(1, "Required").max(100);
const optionalText = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .optional()
    .transform((v) => (v ? v : undefined));

/**
 * Member self-registration (D-011). The new member is PENDING until an
 * Administrator of the chosen parish approves them.
 */
export const RegisterRequestSchema = z
  .object({
    parishId: z.string().uuid("Choose your parish"),
    firstName: name,
    lastName: name,
    otherNames: optionalText(100),
    email: z
      .string()
      .trim()
      .toLowerCase()
      .email("Enter a valid email address")
      .max(254)
      .optional()
      .or(z.literal("").transform(() => undefined)),
    telephone: z
      .string()
      .trim()
      .regex(/^\+[1-9]\d{7,14}$/, "Use the format +233241234567")
      .optional()
      .or(z.literal("").transform(() => undefined)),
    gender: z.enum(["MALE", "FEMALE"]).optional(),
    dateOfBirth: z.string().date("Use YYYY-MM-DD").optional().or(z.literal("").transform(() => undefined)),
    password: PasswordSchema,
  })
  .refine((v) => Boolean(v.email || v.telephone), {
    message: "Give an email address or a phone number so you can sign in",
    path: ["email"],
  });
export type RegisterRequest = z.input<typeof RegisterRequestSchema>;

export const RegisterResponseSchema = z.object({
  status: z.literal("PENDING_APPROVAL"),
  parish: z.object({ id: z.string().uuid(), name: z.string() }),
});
export type RegisterResponse = z.infer<typeof RegisterResponseSchema>;
