import { createDb, members, notifications } from "@ecclesios/db";
import { eq, inArray, sql } from "drizzle-orm";
import request from "supertest";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import type { INestApplication } from "@nestjs/common";
import { createTestApp } from "./app";

const PW = process.env.SEED_DEV_PASSWORD || "Ecclesios#2026";
const G = (n: number) => `00000000-0000-4000-8000-${n.toString().padStart(12, "0")}`;
const PAR_A1 = G(107); // St Theresa Parish
const OUT_A1A = G(110);
const stamp = Date.now();
const NEW_EMAIL = `new.parishioner.${stamp}@dev.ecclesios.local`;
const NEW_PHONE = `+23355${String(stamp).slice(-7)}`;

let app: INestApplication;
const handle = createDb(process.env.DATABASE_URL, { max: 2 });

const cleanup = () =>
  handle.db.delete(members).where(inArray(sql`lower(${members.email})`, [NEW_EMAIL]));

beforeAll(async () => {
  await cleanup();
  ({ app } = await createTestApp());
});
afterAll(async () => {
  await app?.close();
  await cleanup();
  await handle.db.delete(notifications).where(sql`${notifications.link} like ${"%highlight=%"} and ${notifications.title} like ${"Ada Owusu%"}`);
  await handle.close();
});

const body = (over: Record<string, unknown> = {}) => ({
  parishId: PAR_A1,
  firstName: "Ada",
  lastName: "Owusu",
  email: NEW_EMAIL,
  telephone: NEW_PHONE,
  password: "AdaPassword2026",
  ...over,
});

describe("GET /api/public/parishes", () => {
  it("lists active parishes with deanery and diocese, no auth needed", async () => {
    const r = await request(app.getHttpServer()).get("/api/public/parishes?q=theresa").expect(200);
    expect(r.body.items).toEqual([
      { id: PAR_A1, name: "St Theresa Parish", deanery: "St Joseph Deanery", diocese: "Sample Suffragan Diocese" },
    ]);
  });
  it("never returns outstations or higher levels", async () => {
    const r = await request(app.getHttpServer()).get("/api/public/parishes").expect(200);
    expect(r.body.items.length).toBe(4);
    expect(r.body.items.some((p: { id: string }) => p.id === OUT_A1A)).toBe(false);
  });
});

describe("POST /api/auth/register (D-011)", () => {
  it("creates a PENDING parishioner in the chosen parish and notifies its administrator", async () => {
    const r = await request(app.getHttpServer()).post("/api/auth/register").send(body()).expect(201);
    expect(r.body).toEqual({ status: "PENDING_APPROVAL", parish: { id: PAR_A1, name: "St Theresa Parish" } });

    const [m] = await handle.db.select().from(members).where(eq(members.email, NEW_EMAIL));
    expect(m).toMatchObject({ status: "PENDING", groupId: PAR_A1 });
    expect(m!.passwordHash).not.toContain("AdaPassword");
    const note = await handle.db.select().from(notifications).where(sql`${notifications.title} like ${"Ada Owusu%"}`);
    expect(note.length).toBeGreaterThan(0);
  });

  it("signing in before approval → 403 ACCOUNT_PENDING_APPROVAL", async () => {
    const r = await request(app.getHttpServer())
      .post("/api/auth/login")
      .send({ identifier: NEW_EMAIL, password: "AdaPassword2026" })
      .expect(403);
    expect(r.body.error.code).toBe("ACCOUNT_PENDING_APPROVAL");
  });

  it("refuses a duplicate email or phone with 409 ACCOUNT_EXISTS", async () => {
    const r = await request(app.getHttpServer()).post("/api/auth/register").send(body({ telephone: undefined })).expect(409);
    expect(r.body.error.code).toBe("ACCOUNT_EXISTS");
  });

  it("refuses an outstation or unknown group as the parish", async () => {
    const r = await request(app.getHttpServer())
      .post("/api/auth/register")
      .send(body({ parishId: OUT_A1A, email: `x${stamp}@x.test`, telephone: undefined }))
      .expect(400);
    expect(r.body.error.code).toBe("PARISH_NOT_FOUND");
  });

  it("validates the form (contact required, password policy)", async () => {
    const r = await request(app.getHttpServer())
      .post("/api/auth/register")
      .send(body({ email: "", telephone: "", password: "short" }))
      .expect(400);
    expect(r.body.error.code).toBe("VALIDATION_FAILED");
  });

  it("the seeded pending member is also blocked", async () => {
    const r = await request(app.getHttpServer())
      .post("/api/auth/login")
      .send({ identifier: "esi.mensah@dev.ecclesios.local", password: PW })
      .expect(403);
    expect(r.body.error.code).toBe("ACCOUNT_PENDING_APPROVAL");
  });
});
