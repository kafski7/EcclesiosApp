import { describe, expect, it } from "vitest";
import { ancestorIds, describeParish, type NamedNode } from "./parish-label";

const nodes = new Map<string, NamedNode>([
  ["p", { id: "p", name: "Province", level: "PROVINCE" }],
  ["a", { id: "a", name: "Metropolitan Archdiocese", level: "ARCHDIOCESE" }],
  ["d", { id: "d", name: "Suffragan Diocese", level: "DIOCESE" }],
  ["dn", { id: "dn", name: "St Joseph Deanery", level: "DEANERY" }],
  ["ad", { id: "ad", name: "Cathedral Deanery", level: "DEANERY" }],
]);

describe("describeParish", () => {
  it("names the deanery and the nearest diocese for a suffragan parish", () => {
    expect(describeParish("/p/a/d/dn/x/", nodes)).toEqual({ deanery: "St Joseph Deanery", diocese: "Suffragan Diocese" });
  });
  it("uses the archdiocese for the archdiocese's own parishes", () => {
    expect(describeParish("/p/a/ad/y/", nodes)).toEqual({ deanery: "Cathedral Deanery", diocese: "Metropolitan Archdiocese" });
  });
  it("tolerates missing ancestors", () => {
    expect(describeParish("/zz/y/", nodes)).toEqual({ deanery: null, diocese: null });
  });
  it("collects unique ancestor ids", () => {
    expect(ancestorIds(["/p/a/d/dn/x/", "/p/a/ad/y/"]).sort()).toEqual(["a", "ad", "d", "dn", "p"]);
  });
});
