import { Body, Controller, Get, HttpCode, Post, Query, Req } from "@nestjs/common";
import {
  ParishSearchQuerySchema,
  RegisterRequestSchema,
  type ParishSearchResponse,
  type RegisterResponse,
} from "@ecclesios/shared";
import type { Request } from "express";
import type { z } from "zod";
import { Public } from "../common/public.decorator";
import { ZodPipe } from "../common/zod.pipe";
import { RegistrationService } from "./registration.service";

/** Public sign-up endpoints (functionality §2.4). */
@Public()
@Controller()
export class RegistrationController {
  constructor(private readonly registration: RegistrationService) {}

  /** GET /api/public/parishes?q=the — parish picker on the sign-up screen. */
  @Get("public/parishes")
  async parishes(
    @Query(new ZodPipe(ParishSearchQuerySchema)) query: z.output<typeof ParishSearchQuerySchema>,
  ): Promise<ParishSearchResponse> {
    return { items: await this.registration.searchParishes(query.q) };
  }

  /** POST /api/auth/register — creates a PENDING member in the chosen parish. */
  @Post("auth/register")
  @HttpCode(201)
  register(
    @Body(new ZodPipe(RegisterRequestSchema)) body: z.output<typeof RegisterRequestSchema>,
    @Req() req: Request,
  ): Promise<RegisterResponse> {
    return this.registration.register(body, req.ip ?? req.socket.remoteAddress ?? "unknown");
  }
}
