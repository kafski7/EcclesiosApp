import { Inject, Injectable, Logger } from "@nestjs/common";
import { groups, members, notificationTypes, notifications, roles } from "@ecclesios/db";
import type { ParishOption, RegisterRequestSchema, RegisterResponse } from "@ecclesios/shared";
import { and, asc, eq, ilike, inArray, or, sql } from "drizzle-orm";
import type { z } from "zod";
import { AuditService } from "../audit/audit.service";
import { ArgonHasher } from "../auth/argon-hasher";
import { RATE_LIMIT_STORE } from "../auth/auth.service";
import { DomainError } from "../auth/core/errors";
import { RateLimiter, type RateLimitStore } from "../auth/core/rate-limit";
import { DB, type Database } from "../db/db.module";
import { ancestorIds, describeParish, type NamedNode } from "./parish-label";

type RegisterInput = z.output<typeof RegisterRequestSchema>;

const REGISTER_LIMIT = { limit: 10, windowMs: 60 * 60_000 }; // per IP per hour

/**
 * Member self-registration (functionality §2.4, D-011):
 * the person picks their parish, the account is created as PENDING, and the
 * parish Administrators are notified to approve it (approval UI: Phase 6).
 */
@Injectable()
export class RegistrationService {
  private readonly logger = new Logger(RegistrationService.name);
  private readonly limiter: RateLimiter;

  constructor(
    @Inject(DB) private readonly db: Database,
    private readonly hasher: ArgonHasher,
    private readonly audit: AuditService,
    @Inject(RATE_LIMIT_STORE) store: RateLimitStore,
  ) {
    this.limiter = new RateLimiter(store);
  }

  /** Active parishes matching `q` (name or code), with deanery/diocese context. Max 20. */
  async searchParishes(q: string): Promise<ParishOption[]> {
    const term = q.trim();
    const where = and(
      eq(groups.level, "PARISH"),
      eq(groups.isActive, true),
      term ? or(ilike(groups.name, `%${escapeLike(term)}%`), ilike(groups.code, `${escapeLike(term)}%`)) : undefined,
    );
    const rows = await this.db
      .select({ id: groups.id, name: groups.name, path: groups.path })
      .from(groups)
      .where(where)
      .orderBy(asc(groups.name))
      .limit(20);
    if (!rows.length) return [];

    const ids = ancestorIds(rows.map((r) => r.path));
    const ancestors = ids.length
      ? await this.db
          .select({ id: groups.id, name: groups.name, level: groups.level })
          .from(groups)
          .where(inArray(groups.id, ids))
      : [];
    const byId = new Map<string, NamedNode>(ancestors.map((a) => [a.id, a]));
    return rows.map((r) => ({ id: r.id, name: r.name, ...describeParish(r.path, byId) }));
  }

  async register(input: RegisterInput, ip: string): Promise<RegisterResponse> {
    await this.limiter.consume([{ key: `register:ip:${ip}`, ...REGISTER_LIMIT }]);

    const [parish] = await this.db
      .select({ id: groups.id, name: groups.name })
      .from(groups)
      .where(and(eq(groups.id, input.parishId), eq(groups.level, "PARISH"), eq(groups.isActive, true)))
      .limit(1);
    if (!parish) throw new DomainError(400, "PARISH_NOT_FOUND", "Choose your parish from the list.");

    // D-011: say plainly that the email/phone is taken — sign-up is rate-limited per IP.
    const taken = await this.db
      .select({ id: members.id })
      .from(members)
      .where(
        or(
          input.email ? sql`lower(${members.email}) = ${input.email.toLowerCase()}` : undefined,
          input.telephone ? eq(members.telephone, input.telephone) : undefined,
        ),
      )
      .limit(1);
    if (taken.length) throw accountExists();

    const [role] = await this.db.select({ id: roles.id }).from(roles).where(eq(roles.code, "PARISHIONER")).limit(1);
    if (!role) throw new DomainError(500, "SETUP_INCOMPLETE", "Registration is not available yet.");

    const passwordHash = await this.hasher.hash(input.password);
    let memberId: string;
    try {
      const [row] = await this.db
        .insert(members)
        .values({
          groupId: parish.id,
          roleId: role.id,
          status: "PENDING",
          firstName: input.firstName,
          lastName: input.lastName,
          otherNames: input.otherNames ?? null,
          email: input.email ?? null,
          telephone: input.telephone ?? null,
          gender: input.gender ?? null,
          dateOfBirth: input.dateOfBirth ?? null,
          passwordHash,
          firstLogin: new Date(), // they chose their own password, so no "set password" step later
        })
        .returning({ id: members.id });
      memberId = row!.id;
    } catch (err) {
      if (isUniqueViolation(err)) throw accountExists(); // lost a race with an identical sign-up
      throw err;
    }

    await this.notifyParishAdmins(parish.id, memberId, `${input.firstName} ${input.lastName}`);
    await this.audit.write({
      actorType: "MEMBER",
      actorId: memberId,
      groupId: parish.id,
      action: "member.registered",
      entityType: "member",
      entityId: memberId,
      metadata: { channel: input.email ? "email" : "telephone" },
      ip,
    });
    return { status: "PENDING_APPROVAL", parish };
  }

  private async notifyParishAdmins(parishId: string, memberId: string, fullName: string) {
    try {
      const [type] = await this.db
        .select({ id: notificationTypes.id })
        .from(notificationTypes)
        .where(eq(notificationTypes.code, "MEMBER_REGISTRATION"))
        .limit(1);
      if (!type) return;
      const admins = await this.db
        .select({ id: members.id })
        .from(members)
        .innerJoin(roles, eq(members.roleId, roles.id))
        .where(and(eq(members.groupId, parishId), eq(roles.code, "ADMINISTRATOR"), eq(members.status, "ACTIVE")));
      if (!admins.length) return;
      await this.db.insert(notifications).values(
        admins.map((a) => ({
          typeId: type.id,
          groupId: parishId,
          recipientMemberId: a.id,
          title: `${fullName} asked to join your parish`,
          body: "Review the request in Members → Pending.",
          link: `/admin/members?status=PENDING&highlight=${memberId}`,
        })),
      );
    } catch (err) {
      // A failed notification must not undo a successful sign-up.
      this.logger.error({ err, parishId }, "could not notify parish administrators");
    }
  }
}

const accountExists = () =>
  new DomainError(
    409,
    "ACCOUNT_EXISTS",
    "An account with this email or phone number already exists. Try signing in instead.",
  );

const isUniqueViolation = (err: unknown) =>
  typeof err === "object" && err !== null && (err as { code?: string }).code === "23505";

/** Treat user input literally inside LIKE patterns. */
const escapeLike = (s: string) => s.replace(/[\\%_]/g, (c) => `\\${c}`);
