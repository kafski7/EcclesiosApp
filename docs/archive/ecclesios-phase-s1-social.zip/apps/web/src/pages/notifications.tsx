import { safeInternalLink, timeAgo } from "@ecclesios/shared/domain";
import { Bell } from "lucide-react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { isCmsLink, useMarkRead, useNotifications } from "@/lib/account";
import { env } from "@/lib/env";
import { useSession } from "@/stores/session";

/** Your notifications (functionality §4.6, D-039). */
export function NotificationsPage() {
  const principal = useSession((s) => s.principal);
  const navigate = useNavigate();
  const [unreadOnly, setUnreadOnly] = useState(false);
  const q = useNotifications(unreadOnly);
  const mark = useMarkRead();
  const unread = q.data?.pages[0]?.unread ?? 0;

  if (!principal)
    return (
      <div className="content-narrow mx-auto card rail-card">
        <h1 className="page-title">Notifications</h1>
        <p className="page-sub mt-2">
          <Link to="/login" className="link">Sign in</Link> to see news from your church, replies and approvals.
        </p>
      </div>
    );

  const open = (id: string, read: boolean, link: string | null) => {
    if (!read) mark.mutate([id]);
    const to = safeInternalLink(link);
    if (!to) return;
    if (isCmsLink(to)) window.location.href = `${env.VITE_ADMIN_URL}${to}`;
    else navigate(to);
  };

  const items = q.data?.pages.flatMap((p) => p.items) ?? [];
  return (
    <div className="content-narrow mx-auto">
      <header className="page-head flex items-end justify-between gap-3">
        <div>
          <h1 className="page-title">Notifications</h1>
          <p className="page-sub">{unread ? `${unread} unread` : "You're up to date."}</p>
        </div>
        <button type="button" className="btn btn-outline btn-sm" disabled={!unread || mark.isPending} onClick={() => mark.mutate(undefined)}>
          Mark all as read
        </button>
      </header>
      <div className="feed-tabs mb-3" role="tablist">
        <button type="button" role="tab" aria-selected={!unreadOnly} className={!unreadOnly ? "active" : ""} onClick={() => setUnreadOnly(false)}>
          All
        </button>
        <button type="button" role="tab" aria-selected={unreadOnly} className={unreadOnly ? "active" : ""} onClick={() => setUnreadOnly(true)}>
          Unread
        </button>
      </div>
      <section className="card rail-card">
        {q.isPending ? <p className="muted small">Loading…</p> : null}
        {q.isSuccess && !items.length ? (
          <p className="muted small flex items-center gap-2">
            <Bell className="ic" aria-hidden /> Nothing here yet.
          </p>
        ) : null}
        <ul className="notif-list">
          {items.map((n) => (
            <li key={n.id} className={n.read ? "" : "unread"}>
              <span className="notif-dot" aria-hidden />
              <button type="button" className="text-left flex-1" onClick={() => open(n.id, n.read, n.link)}>
                <b>{n.title}</b>
                {n.body ? <div className="small">{n.body}</div> : null}
                <div className="small muted">
                  {timeAgo(n.createdAt)}
                  {n.church ? ` · ${n.church.name}` : ""}
                </div>
              </button>
            </li>
          ))}
        </ul>
        {q.hasNextPage ? (
          <button type="button" className="btn btn-ghost btn-sm mt-2" disabled={q.isFetchingNextPage} onClick={() => void q.fetchNextPage()}>
            Older notifications
          </button>
        ) : null}
      </section>
    </div>
  );
}
