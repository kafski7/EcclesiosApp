import { Module } from "@nestjs/common";
import { BibleController } from "./bible.controller";
import { BibleService } from "./bible.service";
import { ReadingsController } from "./readings.controller";
import { ReadingsService } from "./readings.service";

/** Social content (Phase 5): Readings, Bible; Saints, Hymnal, Podcasts, Teachings, Explore, feed next. */
@Module({
  controllers: [ReadingsController, BibleController],
  providers: [ReadingsService, BibleService],
})
export class SocialModule {}
