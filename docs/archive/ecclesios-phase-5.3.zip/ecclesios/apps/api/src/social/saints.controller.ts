import { Body, Controller, Get, Param, Put, Query, Req } from "@nestjs/common";
import {
  SaintSearchQuerySchema,
  SaintSlugSchema,
  SaintsTodayQuerySchema,
  UpsertSaintSchema,
  type Principal,
  type Saint,
  type SaintSummary,
  type SaintsToday,
} from "@ecclesios/shared";
import { toIsoDate } from "@ecclesios/shared/domain";
import type { Request } from "express";
import type { z } from "zod";
import { CurrentPrincipal } from "../common/principal.decorator";
import { Public } from "../common/public.decorator";
import { ZodPipe } from "../common/zod.pipe";
import { PlatformRole } from "../platform/platform-role";
import { SaintsService } from "./saints.service";

@Controller()
export class SaintsController {
  constructor(private readonly saints: SaintsService) {}

  /** GET /api/public/saints/today?date=YYYY-MM-DD — send the reader's local date; defaults to UTC today. */
  @Public()
  @Get("public/saints/today")
  today(@Query(new ZodPipe(SaintsTodayQuerySchema)) q: z.output<typeof SaintsTodayQuerySchema>): Promise<SaintsToday> {
    return this.saints.today(q.date ?? toIsoDate(new Date()));
  }

  /** GET /api/public/saints?q=&month= — the directory, in calendar order. */
  @Public()
  @Get("public/saints")
  async list(@Query(new ZodPipe(SaintSearchQuerySchema)) q: z.output<typeof SaintSearchQuerySchema>): Promise<{ items: SaintSummary[] }> {
    return { items: await this.saints.list(q.q, q.month) };
  }

  @Public()
  @Get("public/saints/:slug")
  bySlug(@Param("slug", new ZodPipe(SaintSlugSchema)) slug: string): Promise<Saint> {
    return this.saints.bySlug(slug);
  }

  @PlatformRole("SUPER_ADMIN")
  @Put("platform/saints/:slug")
  upsert(
    @Param("slug", new ZodPipe(SaintSlugSchema)) slug: string,
    @Body(new ZodPipe(UpsertSaintSchema)) body: z.output<typeof UpsertSaintSchema>,
    @CurrentPrincipal() p: Principal | undefined,
    @Req() req: Request,
  ) {
    return this.saints.upsert(p!.id, slug, body, req.ip ?? "unknown");
  }
}
