import { Inject, Injectable } from "@nestjs/common";
import { saints } from "@ecclesios/db";
import type { Saint, SaintSummary, SaintsToday, UpsertSaintSchema } from "@ecclesios/shared";
import { compareFeasts, feastOf, saintsOn } from "@ecclesios/shared/domain";
import { and, eq, ilike, or, sql } from "drizzle-orm";
import type { z } from "zod";
import { AuditService } from "../audit/audit.service";
import { DomainError } from "../auth/core/errors";
import { DB, type Database } from "../db/db.module";

type Row = typeof saints.$inferSelect;
type Upsert = z.output<typeof UpsertSaintSchema>;

/** Images are object-storage keys; presigned URLs arrive with the media module (Phase 5.4). */
const summary = (r: Row): SaintSummary => ({
  slug: r.slug,
  name: r.name,
  title: r.title,
  feastMonth: r.feastMonth,
  feastDay: r.feastDay,
  rank: r.rank,
  summary: r.summary,
  patronage: r.patronage,
  imageUrl: null,
});

const escapeLike = (s: string) => s.replace(/[\\%_]/g, (c) => `\\${c}`);

/** Saints directory and saint of the day (functionality §3.3, D-025). */
@Injectable()
export class SaintsService {
  constructor(
    @Inject(DB) private readonly db: Database,
    private readonly audit: AuditService,
  ) {}

  async today(date: string): Promise<SaintsToday> {
    const { month, day } = feastOf(date);
    const rows = await this.db
      .select()
      .from(saints)
      .where(and(eq(saints.isPublished, true), eq(saints.feastMonth, month), eq(saints.feastDay, day)));
    const ordered = saintsOn(rows, date).map(summary);
    return { date, saint: ordered[0] ?? null, others: ordered.slice(1) };
  }

  async list(q: string, month?: number): Promise<SaintSummary[]> {
    const term = q.trim();
    const rows = await this.db
      .select()
      .from(saints)
      .where(
        and(
          eq(saints.isPublished, true),
          month ? eq(saints.feastMonth, month) : undefined,
          term
            ? or(
                ilike(saints.name, `%${escapeLike(term)}%`),
                ilike(saints.summary, `%${escapeLike(term)}%`),
                sql`${saints.patronage}::text ilike ${`%${escapeLike(term)}%`}`,
              )
            : undefined,
        ),
      )
      .limit(400);
    return rows.sort(compareFeasts).map(summary);
  }

  async bySlug(slug: string): Promise<Saint> {
    const [r] = await this.db
      .select()
      .from(saints)
      .where(and(eq(saints.slug, slug), eq(saints.isPublished, true)))
      .limit(1);
    if (!r) throw new DomainError(404, "SAINT_NOT_FOUND", "We couldn't find that saint.");
    return { ...summary(r), born: r.born, died: r.died, biography: r.biography, source: r.source };
  }

  /** Super-Admin: create or replace by slug. Unpublished saints are hidden from the public. */
  async upsert(userId: string, slug: string, body: Upsert, ip: string) {
    const values = {
      slug,
      name: body.name,
      title: body.title,
      feastMonth: body.feastMonth,
      feastDay: body.feastDay,
      rank: body.rank,
      summary: body.summary,
      patronage: body.patronage,
      born: body.born,
      died: body.died,
      biography: body.biography,
      source: body.source,
      isPublished: body.isPublished,
    };
    const [r] = await this.db
      .insert(saints)
      .values(values)
      .onConflictDoUpdate({ target: saints.slug, set: { ...values, updatedAt: new Date() } })
      .returning();
    await this.audit.write({ actorType: "USER", actorId: userId, action: "saints.upserted", entityType: "saint", entityId: slug, ip });
    return { ...summary(r!), born: r!.born, died: r!.died, biography: r!.biography, source: r!.source, isPublished: r!.isPublished };
  }
}
