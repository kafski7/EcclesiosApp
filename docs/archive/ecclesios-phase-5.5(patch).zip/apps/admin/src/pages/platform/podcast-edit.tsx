import { CAlert, CBadge, CButton, CForm, CFormCheck, CFormInput, CFormLabel, CFormText, CFormTextarea } from "@coreui/react";
import type { StudioPodcast } from "@ecclesios/shared";
import { formatEpisodeDuration } from "@ecclesios/shared/domain";
import { useEffect, useState, type FormEvent } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ApiClientError } from "@/lib/api";
import { authErrorMessage } from "@/lib/auth-errors";
import {
  isCoverType,
  useAddEpisode,
  useEpisodeStatus,
  useRemoveEpisode,
  useSavePodcast,
  useStudioPodcast,
  useUpdateEpisode,
  useUploadAudio,
  useUploadCover,
} from "@/lib/podcasts";

const errText = (e: unknown) =>
  e instanceof ApiClientError ? (e.code.startsWith("HTTP_") ? authErrorMessage(e) : e.message) : e instanceof Error ? e.message : "Something went wrong.";

/** Create / edit a series and its episodes (D-027). */
export function PodcastEditPage() {
  const { slug } = useParams();
  const isNew = !slug || slug === "new";
  const q = useStudioPodcast(isNew ? undefined : slug);
  if (!isNew && q.isPending) return <p className="muted">Loading…</p>;
  if (!isNew && q.isError) return <CAlert color="danger">{errText(q.error)}</CAlert>;
  return (
    <>
      <Link to="/platform/podcasts" className="link mb-3 d-inline-block">← All podcasts</Link>
      <SeriesForm podcast={isNew ? null : q.data!} />
      {!isNew && q.data ? (
        <>
          <CoverPanel podcast={q.data} />
          <Episodes podcast={q.data} />
        </>
      ) : null}
    </>
  );
}

function SeriesForm({ podcast }: { podcast: StudioPodcast | null }) {
  const navigate = useNavigate();
  const save = useSavePodcast(podcast?.slug);
  const [title, setTitle] = useState(podcast?.title ?? "");
  const [summary, setSummary] = useState(podcast?.summary ?? "");
  const [description, setDescription] = useState(podcast?.description ?? "");
  const [category, setCategory] = useState(podcast?.category ?? "");
  const [published, setPublished] = useState(podcast?.isPublished ?? true);
  useEffect(() => {
    if (save.data && !podcast) navigate(`/platform/podcasts/${save.data.slug}`, { replace: true });
  }, [save.data, podcast, navigate]);
  const submit = (e: FormEvent) => {
    e.preventDefault();
    save.mutate({ title, summary, description, category: category.trim() || null, isPublished: published });
  };
  return (
    <section className="card panel mb-4">
      <h1 style={{ fontSize: 24, fontWeight: 700 }}>{podcast ? podcast.title : "New series"}</h1>
      {podcast ? <p className="small muted">{podcast.followers} follower{podcast.followers === 1 ? "" : "s"}</p> : null}
      {save.error ? <CAlert color="danger">{errText(save.error)}</CAlert> : null}
      {save.isSuccess && podcast ? <CAlert color="success">Saved.</CAlert> : null}
      <CForm onSubmit={submit}>
        <div className="mb-3">
          <CFormLabel htmlFor="pt">Title</CFormLabel>
          <CFormInput id="pt" value={title} onChange={(e) => setTitle(e.target.value)} required />
        </div>
        <div className="mb-3">
          <CFormLabel htmlFor="ps">One-line summary</CFormLabel>
          <CFormInput id="ps" value={summary} maxLength={280} onChange={(e) => setSummary(e.target.value)} required />
        </div>
        <div className="mb-3">
          <CFormLabel htmlFor="pd">About this podcast</CFormLabel>
          <CFormTextarea id="pd" rows={4} value={description} onChange={(e) => setDescription(e.target.value)} />
        </div>
        <div className="mb-3">
          <CFormLabel htmlFor="pc">Category</CFormLabel>
          <CFormInput id="pc" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="reflection, youth, catechesis…" />
        </div>
        <CFormCheck id="pp" label="Visible to listeners" checked={published} onChange={(e) => setPublished(e.target.checked)} />
        <CButton type="submit" color="primary" className="mt-3" disabled={save.isPending}>
          {save.isPending ? "Saving…" : podcast ? "Save changes" : "Create series"}
        </CButton>
      </CForm>
    </section>
  );
}

function CoverPanel({ podcast }: { podcast: StudioPodcast }) {
  const upload = useUploadCover(podcast.slug);
  const [bad, setBad] = useState(false);
  return (
    <section className="card panel mb-4 d-flex gap-4 align-items-center flex-wrap">
      {podcast.coverUrl ? (
        <img src={podcast.coverUrl} alt="" style={{ width: 96, height: 96, borderRadius: 14, objectFit: "cover" }} />
      ) : (
        <span className="small muted">No cover image</span>
      )}
      <div>
        <CFormLabel htmlFor="cover">Cover image (square, JPEG/PNG/WebP, max 5 MB)</CFormLabel>
        <CFormInput
          id="cover"
          type="file"
          accept="image/jpeg,image/png,image/webp"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (!f) return;
            setBad(!isCoverType(f.type));
            if (isCoverType(f.type)) upload.mutate(f);
          }}
        />
        {podcast.coverUrl ? (
          <CButton size="sm" color="danger" variant="ghost" className="mt-2" onClick={() => upload.mutate(null)}>
            Remove cover
          </CButton>
        ) : null}
        {bad ? <CFormText className="text-danger">Use a JPEG, PNG or WebP image.</CFormText> : null}
        {upload.isPending ? <CFormText>Uploading…</CFormText> : null}
        {upload.error ? <CAlert color="danger" className="mt-2">{errText(upload.error)}</CAlert> : null}
      </div>
    </section>
  );
}

function Episodes({ podcast }: { podcast: StudioPodcast }) {
  const add = useAddEpisode(podcast.slug);
  const [title, setTitle] = useState("");
  const [number, setNumber] = useState("");
  const next = Math.max(0, ...podcast.episodes.map((e) => e.number ?? 0)) + 1;
  return (
    <section className="card panel">
      <h2 className="panel-title mb-3">Episodes</h2>
      <CForm
        className="d-flex gap-2 flex-wrap mb-4"
        onSubmit={(e) => {
          e.preventDefault();
          if (title.trim())
            add.mutate(
              { title: title.trim(), notes: "", number: number ? Number(number) : next },
              { onSuccess: () => { setTitle(""); setNumber(""); } },
            );
        }}
      >
        <CFormInput style={{ maxWidth: 90 }} type="number" min={1} placeholder={String(next)} aria-label="Episode number" value={number} onChange={(e) => setNumber(e.target.value)} />
        <CFormInput style={{ flex: 1, minWidth: 220 }} placeholder="New episode title" aria-label="New episode title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <CButton type="submit" color="primary" disabled={add.isPending || title.trim().length < 2}>Add draft</CButton>
      </CForm>
      {add.error ? <CAlert color="danger">{errText(add.error)}</CAlert> : null}
      {podcast.episodes.length ? (
        podcast.episodes.map((e) => <EpisodeCard key={e.id} slug={podcast.slug} e={e} />)
      ) : (
        <p className="small muted">No episodes yet.</p>
      )}
    </section>
  );
}

function EpisodeCard({ slug, e }: { slug: string; e: StudioPodcast["episodes"][number] }) {
  const update = useUpdateEpisode(slug);
  const status = useEpisodeStatus(slug);
  const remove = useRemoveEpisode(slug);
  const upload = useUploadAudio(slug);
  const [title, setTitle] = useState(e.title);
  const [notes, setNotes] = useState(e.notes);
  const [number, setNumber] = useState(e.number ? String(e.number) : "");
  const err = update.error ?? status.error ?? remove.error ?? upload.error;
  const live = e.status === "PUBLISHED";

  return (
    <div className="card p-3 mb-3">
      <div className="d-flex gap-2 align-items-center flex-wrap mb-2">
        {live ? <CBadge color="success">Published</CBadge> : <CBadge color="secondary">Draft</CBadge>}
        {e.hasAudio ? <span className="small muted">Audio {formatEpisodeDuration(e.durationSec)}</span> : <span className="small text-danger">No audio yet</span>}
        <span className="ms-auto d-flex gap-2">
          <CButton
            size="sm"
            color={live ? "secondary" : "primary"}
            variant={live ? "outline" : undefined}
            disabled={status.isPending || (!live && !e.hasAudio)}
            title={!live && !e.hasAudio ? "Upload audio first" : undefined}
            onClick={() => status.mutate({ id: e.id, status: live ? "DRAFT" : "PUBLISHED" })}
          >
            {live ? "Unpublish" : "Publish"}
          </CButton>
          <CButton size="sm" color="danger" variant="ghost" onClick={() => confirm(`Delete "${e.title}" and its audio?`) && remove.mutate(e.id)}>
            Delete
          </CButton>
        </span>
      </div>
      <div className="d-flex gap-2 mb-2">
        <CFormInput style={{ maxWidth: 90 }} type="number" min={1} aria-label="Number" value={number} onChange={(x) => setNumber(x.target.value)} />
        <CFormInput aria-label="Title" value={title} onChange={(x) => setTitle(x.target.value)} />
      </div>
      <CFormTextarea rows={3} aria-label="Show notes" placeholder="Show notes" value={notes} onChange={(x) => setNotes(x.target.value)} className="mb-2" />
      <div className="d-flex gap-2 align-items-center flex-wrap">
        <CButton size="sm" color="primary" variant="outline" disabled={update.isPending} onClick={() => update.mutate({ id: e.id, body: { title, notes, number: number ? Number(number) : null } })}>
          Save
        </CButton>
        <CFormInput
          size="sm"
          type="file"
          accept="audio/mpeg,audio/mp4,audio/aac,audio/ogg,.mp3,.m4a"
          style={{ maxWidth: 320 }}
          aria-label={e.hasAudio ? "Replace audio" : "Upload audio"}
          onChange={(x) => {
            const f = x.target.files?.[0];
            if (f) upload.mutate({ id: e.id, file: f });
          }}
        />
        {upload.isPending ? <span className="small muted">Uploading…</span> : null}
        {e.audioUrl ? <audio src={e.audioUrl} controls preload="none" style={{ height: 32 }} /> : null}
      </div>
      {err ? <CAlert color="danger" className="mt-2 mb-0">{errText(err)}</CAlert> : null}
    </div>
  );
}
