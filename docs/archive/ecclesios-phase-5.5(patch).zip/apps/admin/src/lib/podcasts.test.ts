import { describe, expect, it } from "vitest";
import { audioType, isCoverType } from "./podcasts";

describe("studio uploads", () => {
  it("guesses audio types from the extension", () => {
    expect(audioType({ type: "", name: "ep1.MP3" })).toBe("audio/mpeg");
    expect(audioType({ type: "audio/mp4", name: "x" })).toBe("audio/mp4");
  });
  it("accepts only image covers", () => {
    expect(isCoverType("image/webp")).toBe(true);
    expect(isCoverType("image/gif")).toBe(false);
  });
});
