import { createDb, notifications, podcastEpisodes, podcasts } from "@ecclesios/db";
import { eq, like } from "drizzle-orm";
import request from "supertest";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import type { INestApplication } from "@nestjs/common";
import { createTestApp, signInCache } from "./app";

// Phase 5.5 Podcasts (functionality §3.5, D-027). Presigning is local, so MinIO is not needed.
const SUPER = "superadmin@dev.ecclesios.local";
const CREATOR = "creator@dev.ecclesios.local"; //   platform creator with POST_PODCASTS (owns youth-on-fire)
const THERESA = "theresa.pastor@dev.ecclesios.local"; // member, no podcast grant
const ESI = "esi.mensah@dev.ecclesios.local"; //    member, will follow

let app: INestApplication;
let token: ReturnType<typeof signInCache>;
const handle = createDb(process.env.DATABASE_URL, { max: 2 });
const http = () => request(app.getHttpServer());
const auth = (t: string) => ({ Authorization: `Bearer ${t}` });
const cleanup = async () => {
  await handle.db.delete(podcasts).where(like(podcasts.slug, "e2e-%"));
  await handle.db.delete(notifications).where(like(notifications.title, "E2E Test Podcast%"));
};

beforeAll(async () => {
  await cleanup();
  const t = await createTestApp();
  app = t.app;
  token = signInCache(app, t.otp);
});
afterAll(async () => {
  await app?.close();
  await cleanup();
  await handle.close();
});

describe("public listening", () => {
  it("lists published series; drafts don't count as episodes", async () => {
    const r = await http().get("/api/public/podcasts").expect(200);
    const weekly = r.body.items.find((x: { slug: string }) => x.slug === "ecclesios-weekly");
    expect(weekly).toMatchObject({ publisher: { kind: "PLATFORM", name: "Ecclesios" }, episodeCount: 0 });
    const youth = await http().get("/api/public/podcasts/youth-on-fire").expect(200);
    expect(youth.body).toMatchObject({ publisher: { kind: "CREATOR" }, episodes: [] });
  });
  it("searches and 404s", async () => {
    const r = await http().get("/api/public/podcasts?q=gospel").expect(200);
    expect(r.body.items.map((x: { slug: string }) => x.slug)).toContain("ecclesios-weekly");
    expect((await http().get("/api/public/podcasts/nope").expect(404)).body.error.code).toBe("PODCAST_NOT_FOUND");
  });
});

describe("who may publish (D-027)", () => {
  it("a member without the grant can neither create nor see others' series", async () => {
    const t = await token(THERESA);
    const list = await http().get("/api/studio/podcasts").set(auth(t)).expect(200);
    expect(list.body).toEqual({ canCreate: false, items: [] });
    await http().post("/api/studio/podcasts").set(auth(t)).send({ title: "Nope", summary: "Nope" }).expect(403);
    await http().get("/api/studio/podcasts/ecclesios-weekly").set(auth(t)).expect(403);
  });

  it("a creator sees and manages only their own series", async () => {
    const t = await token(CREATOR, undefined, "admin-login");
    const list = await http().get("/api/studio/podcasts").set(auth(t)).expect(200);
    expect(list.body.canCreate).toBe(true);
    expect(list.body.items.map((x: { slug: string }) => x.slug)).toEqual(["youth-on-fire"]);
    await http().get("/api/studio/podcasts/youth-on-fire").set(auth(t)).expect(200);
    await http().get("/api/studio/podcasts/ecclesios-weekly").set(auth(t)).expect(403);
  });
});

describe("publishing an episode", () => {
  let episodeId = "";

  it("Super-Admin creates a series and a draft episode", async () => {
    const t = await token(SUPER, undefined, "admin-login");
    const r = await http()
      .post("/api/studio/podcasts")
      .set(auth(t))
      .send({ title: "E2E Test Podcast", summary: "Only used by the end-to-end tests.", category: "Test" })
      .expect(201);
    expect(r.body).toMatchObject({ slug: "e2e-test-podcast", category: "test", episodes: [] });
    const e = await http()
      .post("/api/studio/podcasts/e2e-test-podcast/episodes")
      .set(auth(t))
      .send({ title: "First steps", number: 1 })
      .expect(201);
    episodeId = e.body.episodes[0].id;
    expect(e.body.episodes[0]).toMatchObject({ status: "DRAFT", hasAudio: false });
    const dup = await http()
      .post("/api/studio/podcasts/e2e-test-podcast/episodes")
      .set(auth(t))
      .send({ title: "Clash", number: 1 })
      .expect(409);
    expect(dup.body.error.code).toBe("NUMBER_TAKEN");
  });

  it("cannot publish without audio; uploads are type-checked", async () => {
    const t = await token(SUPER, undefined, "admin-login");
    const base = `/api/studio/podcasts/e2e-test-podcast/episodes/${episodeId}`;
    const r = await http().post(`${base}/status`).set(auth(t)).send({ status: "PUBLISHED" }).expect(409);
    expect(r.body.error.code).toBe("AUDIO_REQUIRED");
    await http().post(`${base}/upload`).set(auth(t)).send({ contentType: "video/mp4", bytes: 1000 }).expect(400);
    const ok = await http().post(`${base}/upload`).set(auth(t)).send({ contentType: "audio/mpeg", bytes: 1000 }).expect(201);
    expect(ok.body.key).toMatch(/^podcasts\/.+\/episodes\/.+\.mp3$/);
  });

  it("publishing notifies followers once and shows the episode publicly", async () => {
    const esi = await token(ESI);
    await http().put("/api/podcasts/e2e-test-podcast/follow").set(auth(esi)).expect(204);
    expect((await http().get("/api/podcasts/following").set(auth(esi)).expect(200)).body.slugs).toContain("e2e-test-podcast");

    // Stand-in for a real upload (no storage in e2e): attach a key directly.
    await handle.db.update(podcastEpisodes).set({ audioKey: "podcasts/e2e/episode.mp3", durationSec: 600 }).where(eq(podcastEpisodes.id, episodeId));

    const t = await token(SUPER, undefined, "admin-login");
    const base = `/api/studio/podcasts/e2e-test-podcast/episodes/${episodeId}`;
    await http().post(`${base}/status`).set(auth(t)).send({ status: "PUBLISHED" }).expect(200);
    await http().post(`${base}/status`).set(auth(t)).send({ status: "DRAFT" }).expect(200);
    await http().post(`${base}/status`).set(auth(t)).send({ status: "PUBLISHED" }).expect(200);
    const sent = await handle.db.select().from(notifications).where(like(notifications.title, "E2E Test Podcast%"));
    expect(sent.length).toBe(1);

    const pub = await http().get("/api/public/podcasts/e2e-test-podcast").expect(200);
    expect(pub.body.episodes).toMatchObject([{ id: episodeId, title: "First steps", durationSec: 600 }]);
    const url = await http().get(`/api/public/podcasts/episodes/${episodeId}/url`).expect(200);
    expect(url.body.url).toMatch(/^https?:\/\//);
  });

  it("drafts have no public URL; platform accounts cannot follow", async () => {
    const t = await token(SUPER, undefined, "admin-login");
    const base = `/api/studio/podcasts/e2e-test-podcast/episodes/${episodeId}`;
    await http().post(`${base}/status`).set(auth(t)).send({ status: "DRAFT" }).expect(200);
    await http().get(`/api/public/podcasts/episodes/${episodeId}/url`).expect(404);
    await http().put("/api/podcasts/e2e-test-podcast/follow").set(auth(t)).expect(403);
  });
});
