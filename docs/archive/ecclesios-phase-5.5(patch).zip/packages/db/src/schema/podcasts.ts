import { sql } from "drizzle-orm";
import {
  boolean,
  check,
  index,
  integer,
  pgTable,
  primaryKey,
  smallint,
  text,
  timestamp,
  uniqueIndex,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";
import { id, timestamps } from "./_common";
import { episodeStatusEnum } from "./enums";
import { members, users } from "./identity";

/**
 * Podcasts (functionality §3.5, D-027). A series is owned by exactly one platform account or one
 * member holding POST_PODCASTS; Super-Admins manage all. Audio and covers are object-storage keys.
 */
export const podcasts = pgTable(
  "podcasts",
  {
    id: id(),
    slug: varchar("slug", { length: 100 }).notNull().unique(),
    title: varchar("title", { length: 160 }).notNull(),
    summary: varchar("summary", { length: 280 }).notNull(),
    description: text("description").notNull().default(""),
    category: varchar("category", { length: 40 }),
    coverKey: text("cover_key"),
    ownerUserId: uuid("owner_user_id").references(() => users.id, { onDelete: "restrict" }),
    ownerMemberId: uuid("owner_member_id").references(() => members.id, { onDelete: "restrict" }),
    isPublished: boolean("is_published").notNull().default(true),
    ...timestamps(),
  },
  (t) => [
    index("podcasts_owner_user_idx").on(t.ownerUserId),
    index("podcasts_owner_member_idx").on(t.ownerMemberId),
    check("podcasts_one_owner_chk", sql`(${t.ownerUserId} IS NULL) <> (${t.ownerMemberId} IS NULL)`),
    index("podcasts_fts_idx").using(
      "gin",
      sql`to_tsvector('english', ${t.title} || ' ' || ${t.summary} || ' ' || ${t.description})`,
    ),
  ],
);

export const podcastEpisodes = pgTable(
  "podcast_episodes",
  {
    id: id(),
    podcastId: uuid("podcast_id")
      .notNull()
      .references(() => podcasts.id, { onDelete: "cascade" }),
    number: smallint("number"),
    title: varchar("title", { length: 200 }).notNull(),
    notes: text("notes").notNull().default(""),
    audioKey: text("audio_key"),
    contentType: varchar("content_type", { length: 100 }),
    bytes: integer("bytes"),
    durationSec: integer("duration_sec"),
    status: episodeStatusEnum("status").notNull().default("DRAFT"),
    publishedAt: timestamp("published_at", { withTimezone: true }),
    ...timestamps(),
  },
  (t) => [
    index("podcast_episodes_feed_idx").on(t.podcastId, t.status, t.publishedAt),
    uniqueIndex("podcast_episodes_number_uq")
      .on(t.podcastId, t.number)
      .where(sql`${t.number} IS NOT NULL`),
    check("podcast_episodes_live_chk", sql`${t.status} = 'DRAFT' OR (${t.audioKey} IS NOT NULL AND ${t.publishedAt} IS NOT NULL)`),
  ],
);

/** Members following a series get a notification for each new episode (D-027). */
export const podcastFollows = pgTable(
  "podcast_follows",
  {
    memberId: uuid("member_id")
      .notNull()
      .references(() => members.id, { onDelete: "cascade" }),
    podcastId: uuid("podcast_id")
      .notNull()
      .references(() => podcasts.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.memberId, t.podcastId] }), index("podcast_follows_podcast_idx").on(t.podcastId)],
);
