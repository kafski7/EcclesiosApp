/**
 * Podcasts (functionality §3.5, D-027). Pure rules: who may publish, who may manage a series,
 * and what an upload may be. Dependency-free.
 */
import type { PlatformPrivilege, PlatformRole } from "./levels.js";

export const EPISODE_STATUSES = ["DRAFT", "PUBLISHED"] as const;
export type EpisodeStatus = (typeof EPISODE_STATUSES)[number];

export const PODCAST_AUDIO_TYPES = ["audio/mpeg", "audio/mp4", "audio/x-m4a", "audio/aac", "audio/ogg"] as const;
export const PODCAST_COVER_TYPES = ["image/jpeg", "image/png", "image/webp"] as const;
export const MAX_EPISODE_BYTES = 200 * 1024 * 1024;
export const MAX_COVER_BYTES = 5 * 1024 * 1024;

/** Who is acting. Members and platform accounts can both hold POST_PODCASTS (D-017, D-027). */
export type PodcastActor =
  | { kind: "user"; id: string; role: PlatformRole; privileges: readonly PlatformPrivilege[] }
  | { kind: "member"; id: string; privileges: readonly PlatformPrivilege[] };

/** Owner of a series: exactly one platform account or one member. */
export interface SeriesOwner {
  ownerUserId: string | null;
  ownerMemberId: string | null;
}

export const isPlatformAdmin = (a: PodcastActor) => a.kind === "user" && a.role === "SUPER_ADMIN";

/** May create a series: Super-Admins (primary publishers) and anyone granted POST_PODCASTS. */
export const canPublishPodcasts = (a: PodcastActor) =>
  isPlatformAdmin(a) || a.privileges.includes("POST_PODCASTS");

/**
 * May edit a series and its episodes: Super-Admins always; the owner while they still hold
 * POST_PODCASTS (revoking the grant freezes their series, it does not delete it).
 */
export function canManageSeries(a: PodcastActor, s: SeriesOwner): boolean {
  if (isPlatformAdmin(a)) return true;
  if (!a.privileges.includes("POST_PODCASTS")) return false;
  return a.kind === "user" ? s.ownerUserId === a.id : s.ownerMemberId === a.id;
}

/** An episode can go live only with audio. */
export function canPublishEpisode(e: { audioKey: string | null }): boolean {
  return Boolean(e.audioKey);
}

/** "1:02:05" / "4:09" */
export function formatEpisodeDuration(sec: number | null): string {
  if (sec == null || sec < 0) return "";
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return h ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}
