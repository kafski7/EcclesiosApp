import { z } from "zod";
import { EPISODE_STATUSES, MAX_COVER_BYTES, MAX_EPISODE_BYTES } from "../domain/podcasts.js";

export const PodcastSlugSchema = z.string().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(100);
export const EpisodeStatusSchema = z.enum(EPISODE_STATUSES);

/** Who a series is by, as shown to listeners. */
export const PodcastPublisherSchema = z.object({
  kind: z.enum(["PLATFORM", "CREATOR", "MEMBER"]),
  name: z.string(),
});

export const PodcastSummarySchema = z.object({
  slug: PodcastSlugSchema,
  title: z.string(),
  summary: z.string(),
  category: z.string().nullable(),
  publisher: PodcastPublisherSchema,
  /** Short-lived presigned URL, or null (initials tile). */
  coverUrl: z.string().url().nullable(),
  episodeCount: z.number().int(),
  latestEpisodeAt: z.string().datetime().nullable(),
});
export type PodcastSummary = z.infer<typeof PodcastSummarySchema>;

export const PodcastSearchQuerySchema = z.object({
  q: z.string().trim().max(100).default(""),
  category: z.string().trim().max(40).optional(),
  page: z.coerce.number().int().min(1).default(1),
});
export const PodcastListSchema = z.object({
  items: z.array(PodcastSummarySchema),
  page: z.number().int(),
  hasMore: z.boolean(),
});

export const EpisodeSchema = z.object({
  id: z.string().uuid(),
  number: z.number().int().nullable(),
  title: z.string(),
  notes: z.string(),
  durationSec: z.number().int().nullable(),
  publishedAt: z.string().datetime().nullable(),
});
export type Episode = z.infer<typeof EpisodeSchema>;

export const PodcastSchema = PodcastSummarySchema.extend({
  description: z.string(),
  episodes: z.array(EpisodeSchema),
});
export type Podcast = z.infer<typeof PodcastSchema>;

export const FollowingPodcastsSchema = z.object({ slugs: z.array(PodcastSlugSchema) });

// ------------------------------------------------------------------ publishing (Super-Admin, creators)

export const UpsertPodcastSchema = z.object({
  title: z.string().trim().min(2).max(160),
  summary: z.string().trim().min(2).max(280),
  description: z.string().trim().max(5000).default(""),
  category: z.string().trim().toLowerCase().max(40).nullable().default(null),
  isPublished: z.boolean().default(true),
});
export type UpsertPodcast = z.infer<typeof UpsertPodcastSchema>;

export const UpsertEpisodeSchema = z.object({
  title: z.string().trim().min(2).max(200),
  notes: z.string().trim().max(10000).default(""),
  number: z.coerce.number().int().min(1).max(9999).nullable().default(null),
});
export type UpsertEpisode = z.infer<typeof UpsertEpisodeSchema>;

export const EpisodeUploadSchema = z.object({
  contentType: z.string().max(100),
  bytes: z.number().int().min(1).max(MAX_EPISODE_BYTES, "The file is too large (max 200 MB)."),
});
export const CoverUploadSchema = z.object({
  contentType: z.string().max(100),
  bytes: z.number().int().min(1).max(MAX_COVER_BYTES, "The image is too large (max 5 MB)."),
});
export const AttachAudioSchema = z.object({
  key: z.string().min(5).max(300),
  durationSec: z.number().int().min(1).max(24 * 3600).nullable().default(null),
});
export const AttachCoverSchema = z.object({ key: z.string().min(5).max(300).nullable() });
export const EpisodeStatusChangeSchema = z.object({ status: EpisodeStatusSchema });

export const StudioEpisodeSchema = EpisodeSchema.extend({
  status: EpisodeStatusSchema,
  hasAudio: z.boolean(),
  audioUrl: z.string().url().nullable(),
});
export const StudioPodcastSchema = PodcastSchema.omit({ episodes: true }).extend({
  isPublished: z.boolean(),
  followers: z.number().int(),
  episodes: z.array(StudioEpisodeSchema),
});
export type StudioPodcast = z.infer<typeof StudioPodcastSchema>;
export const StudioPodcastListSchema = z.object({
  items: z.array(
    PodcastSummarySchema.extend({ isPublished: z.boolean(), drafts: z.number().int(), followers: z.number().int() }),
  ),
  /** Whether the caller may create a new series. */
  canCreate: z.boolean(),
});
