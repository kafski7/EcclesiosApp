import {
  BookOpen,
  Compass,
  GraduationCap,
  Home,
  Menu,
  Mic,
  Music,
  ScrollText,
  Sparkles,
  type LucideIcon,
} from "lucide-react";

/** The fixed primary navigation of the social platform (blueprint §2.1, todo Phase 3). */
export interface NavItem {
  to: string;
  label: string;
  icon: LucideIcon;
  /** Shown in the phone bottom bar (max 5 incl. More). */
  mobile?: boolean;
}

export const PRIMARY_NAV: NavItem[] = [
  { to: "/", label: "Home", icon: Home, mobile: true },
  { to: "/readings", label: "Readings", icon: ScrollText, mobile: true },
  { to: "/saints", label: "Saints", icon: Sparkles },
  { to: "/explore", label: "Explore", icon: Compass, mobile: true },
  { to: "/podcasts", label: "Podcasts", icon: Mic },
  { to: "/hymnal", label: "Hymnal", icon: Music },
  { to: "/teachings", label: "Teachings", icon: GraduationCap },
  { to: "/bible", label: "Bible", icon: BookOpen, mobile: true },
];

/** "More" opens the off-canvas menu (functionality §3.9); /more is its full-page fallback. */
export const MORE_ITEM: NavItem = { to: "/more", label: "More", icon: Menu, mobile: true };
