import type { ReactNode } from "react";
import { Card } from "@/components/ui/card";

/** Temporary page body until the section is built (todo Phase 5 / Phase 3 slice 2). */
export function Placeholder({
  title,
  intro,
  coming,
  children,
}: {
  title: string;
  intro: string;
  coming: string;
  children?: ReactNode;
}) {
  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="text-3xl font-bold">{title}</h1>
      <p className="mt-2 text-muted-foreground">{intro}</p>
      <Card className="mt-6 border-dashed p-6">
        <p className="text-sm font-semibold text-primary">Coming soon</p>
        <p className="mt-1 text-sm text-muted-foreground">{coming}</p>
      </Card>
      {children}
    </div>
  );
}
