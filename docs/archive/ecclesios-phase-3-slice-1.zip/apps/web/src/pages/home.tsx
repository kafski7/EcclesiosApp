import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { PRIMARY_NAV } from "@/nav";

/** Home (functionality §3.1). The blended feed replaces these entry cards in Phase 5.8. */
export function HomePage() {
  const sections = PRIMARY_NAV.filter((n) => n.to !== "/");
  return (
    <div>
      <section className="rounded-lg border bg-gradient-to-br from-[#fffdf6] via-[#f7edd6] to-[#f2e3bc] p-8">
        <p className="text-xs font-bold uppercase tracking-[0.14em] text-[#8c6d14]">Welcome</p>
        <h1 className="mt-2 text-3xl font-bold md:text-4xl">Faith, community and Church — in one place.</h1>
        <p className="mt-3 max-w-2xl text-muted-foreground">
          Daily readings, saints, hymns, teachings, podcasts and the Bible — and your church, connected.
        </p>
      </section>

      <h2 className="mt-10 text-xl font-bold">Explore Ecclesios</h2>
      <ul className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {sections.map(({ to, label, icon: Icon }) => (
          <li key={to}>
            <Link to={to} className="group block h-full">
              <Card className="flex h-full items-center gap-4 p-5 transition-shadow group-hover:shadow-md">
                <span className="grid size-11 place-items-center rounded-xl bg-primary/5 text-primary">
                  <Icon className="size-5" />
                </span>
                <span className="flex-1 font-semibold">{label}</span>
                <ArrowRight className="size-4 text-muted-foreground transition-transform group-hover:translate-x-1" />
              </Card>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
