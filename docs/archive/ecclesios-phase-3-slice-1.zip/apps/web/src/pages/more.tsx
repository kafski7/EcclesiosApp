import { HealthResponseSchema } from "@ecclesios/shared";
import { useQuery } from "@tanstack/react-query";
import { MoreMenu } from "@/components/layout/more-menu";
import { api } from "@/lib/query";

/** Full-page version of the More menu (functionality §3.9) + a small API status line. */
export function MorePage() {
  const health = useQuery({
    queryKey: ["health"],
    queryFn: () => api.get("/health", HealthResponseSchema),
    staleTime: 30_000,
  });

  const status = health.isPending
    ? "Checking connection…"
    : health.data?.status === "ok"
      ? "Connected"
      : "Offline — some features are unavailable";

  return (
    <div className="mx-auto max-w-md">
      <h1 className="mb-6 text-3xl font-bold">More</h1>
      <MoreMenu />
      <p className="mt-8 flex items-center gap-2 px-3 text-xs text-muted-foreground" role="status">
        <span className={`size-2 rounded-full ${health.data?.status === "ok" ? "bg-green-600" : "bg-muted-foreground"}`} />
        {status}
      </p>
    </div>
  );
}
