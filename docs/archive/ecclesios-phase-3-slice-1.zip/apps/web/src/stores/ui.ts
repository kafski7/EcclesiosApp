import { create } from "zustand";

/** Small client-only UI state (blueprint §6: Zustand for client state, TanStack Query for server state). */
interface UiState {
  moreOpen: boolean;
  setMoreOpen: (open: boolean) => void;
}

export const useUi = create<UiState>((set) => ({
  moreOpen: false,
  setMoreOpen: (moreOpen) => set({ moreOpen }),
}));
