import { useRegisterSW } from "virtual:pwa-register/react";
import { Button } from "@/components/ui/button";

/** PWA: ask before activating a new version, so nobody loses a half-read page. */
export function UpdatePrompt() {
  const {
    needRefresh: [needRefresh, setNeedRefresh],
    updateServiceWorker,
  } = useRegisterSW();

  if (!needRefresh) return null;
  return (
    <div role="status" className="fixed inset-x-4 bottom-24 z-50 mx-auto flex max-w-md items-center gap-3 rounded-lg border bg-card p-3 shadow-lg lg:bottom-6">
      <p className="flex-1 text-sm">A new version of Ecclesios is ready.</p>
      <Button size="sm" variant="ghost" onClick={() => setNeedRefresh(false)}>
        Later
      </Button>
      <Button size="sm" onClick={() => void updateServiceWorker(true)}>
        Update
      </Button>
    </div>
  );
}
