import { Bell, Building2, Info, LogIn, ShieldCheck, FileText, UserPlus } from "lucide-react";
import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import { SheetClose } from "@/components/ui/sheet";
import { useSession } from "@/stores/session";

/**
 * Contents of the More menu (functionality §3.9). Rendered both in the off-canvas sheet
 * and on the /more page so deep links and no-JS-sheet fallbacks work.
 */
export function MoreMenu({ inSheet = false }: { inSheet?: boolean }) {
  const principal = useSession((s) => s.principal);

  const Item = ({ to, icon, label, hint }: { to: string; icon: ReactNode; label: string; hint?: string }) => {
    const link = (
      <Link to={to} className="flex items-center gap-3 rounded-lg px-3 py-2.5 hover:bg-muted">
        <span className="text-primary [&_svg]:size-5">{icon}</span>
        <span className="flex flex-col">
          <span className="text-sm font-semibold">{label}</span>
          {hint ? <span className="text-xs text-muted-foreground">{hint}</span> : null}
        </span>
      </Link>
    );
    return <li>{inSheet ? <SheetClose asChild>{link}</SheetClose> : link}</li>;
  };

  return (
    <nav aria-label="More" className="flex flex-col gap-6">
      <Section title="Church Management">
        <Item to="/subscribe" icon={<Building2 />} label="Subscribe your church" hint="Basic, Premium or Ultimate" />
        <Item to="/cms-login" icon={<ShieldCheck />} label="Church Management login" hint="For subscribed churches" />
      </Section>
      <Section title="You">
        <Item to="/notifications" icon={<Bell />} label="Notifications" />
        {principal ? null : (
          <>
            <Item to="/login" icon={<LogIn />} label="Sign in" />
            <Item to="/register" icon={<UserPlus />} label="Create an account" />
          </>
        )}
      </Section>
      <Section title="Ecclesios">
        <Item to="/about" icon={<Info />} label="About" />
        <Item to="/privacy" icon={<FileText />} label="Privacy" />
        <Item to="/terms" icon={<FileText />} label="Terms" />
      </Section>
    </nav>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section>
      <h2 className="px-3 pb-1 font-sans text-[11px] font-bold uppercase tracking-[0.14em] text-muted-foreground">
        {title}
      </h2>
      <ul className="flex flex-col">{children}</ul>
    </section>
  );
}
