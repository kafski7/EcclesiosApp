import { Link } from "react-router-dom";

export function Brand({ className = "" }: { className?: string }) {
  return (
    <Link to="/" className={`flex items-center gap-2.5 ${className}`} aria-label="Ecclesios home">
      <img src="/icon.svg" alt="" className="size-8 rounded-lg" />
      <span className="font-serif text-xl font-semibold tracking-wide">Ecclesios</span>
    </Link>
  );
}
