import { Outlet, NavLink } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { MORE_ITEM, PRIMARY_NAV, type NavItem } from "@/nav";
import { useUi } from "@/stores/ui";
import { Brand } from "./brand";
import { MoreMenu } from "./more-menu";
import { UpdatePrompt } from "./update-prompt";

/**
 * Consumer-grade shell (blueprint §2.1 — not a dashboard):
 * top bar + horizontal nav on desktop, bottom tab bar on phones, More as an off-canvas sheet.
 */
export function AppShell() {
  const { moreOpen, setMoreOpen } = useUi();
  const MoreIcon = MORE_ITEM.icon;

  return (
    <div className="flex min-h-dvh flex-col">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-50 focus:rounded focus:bg-card focus:px-3 focus:py-2">
        Skip to content
      </a>

      <header className="sticky top-0 z-40 border-b bg-background/90 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-6 px-4">
          <Brand />
          <nav aria-label="Primary" className="hidden flex-1 items-center gap-1 lg:flex">
            {PRIMARY_NAV.map((item) => (
              <TopLink key={item.to} item={item} />
            ))}
          </nav>
          <Button variant="ghost" size="sm" className="ml-auto" onClick={() => setMoreOpen(true)} aria-haspopup="dialog">
            <MoreIcon /> More
          </Button>
        </div>
      </header>

      <main id="main" className="mx-auto w-full max-w-6xl flex-1 px-4 pb-28 pt-6 lg:pb-12">
        <Outlet />
      </main>

      <footer className="hidden border-t py-6 text-center text-xs text-muted-foreground lg:block">
        Ecclesios · Faith · Community · Church
      </footer>

      <nav aria-label="Primary (mobile)" className="fixed inset-x-0 bottom-0 z-40 border-t bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden">
        <ul className="mx-auto grid max-w-md grid-cols-5">
          {PRIMARY_NAV.filter((n) => n.mobile).map((item) => (
            <li key={item.to}>
              <BottomLink item={item} />
            </li>
          ))}
          <li>
            <button
              type="button"
              onClick={() => setMoreOpen(true)}
              aria-haspopup="dialog"
              className="flex w-full flex-col items-center gap-1 py-2 text-[11px] font-medium text-muted-foreground"
            >
              <MoreIcon className="size-5" />
              More
            </button>
          </li>
        </ul>
      </nav>

      <Sheet open={moreOpen} onOpenChange={setMoreOpen}>
        <SheetContent title="More" description="Church management, your account and Ecclesios.">
          <MoreMenu inSheet />
        </SheetContent>
      </Sheet>

      <UpdatePrompt />
    </div>
  );
}

function TopLink({ item }: { item: NavItem }) {
  return (
    <NavLink
      to={item.to}
      end={item.to === "/"}
      className={({ isActive }) =>
        cn(
          "rounded-full px-3 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-primary",
          isActive && "bg-primary text-primary-foreground hover:text-primary-foreground",
        )
      }
    >
      {item.label}
    </NavLink>
  );
}

function BottomLink({ item }: { item: NavItem }) {
  const Icon = item.icon;
  return (
    <NavLink
      to={item.to}
      end={item.to === "/"}
      className={({ isActive }) =>
        cn("flex flex-col items-center gap-1 py-2 text-[11px] font-medium text-muted-foreground", isActive && "text-primary")
      }
    >
      <Icon className="size-5" />
      {item.label}
    </NavLink>
  );
}
