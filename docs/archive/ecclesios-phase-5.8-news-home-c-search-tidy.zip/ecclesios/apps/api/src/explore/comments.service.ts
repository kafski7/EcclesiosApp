import { Inject, Injectable } from "@nestjs/common";
import { commentReports, members, postComments, posts } from "@ecclesios/db";
import type { Comment, Principal } from "@ecclesios/shared";
import { canModerateComment, COMMENT_REPORT_THRESHOLD, type CommentStatus } from "@ecclesios/shared/domain";
import { asc, desc, eq, gt, sql } from "drizzle-orm";
import { AuditService } from "../audit/audit.service";
import { RATE_LIMIT_STORE } from "../auth/auth.service";
import { DomainError } from "../auth/core/errors";
import { RateLimiter, type RateLimitStore } from "../auth/core/rate-limit";
import { DB, type Database } from "../db/db.module";
import { ExploreAccess } from "./explore-access";
import { ExploreService } from "./explore.service";

const COMMENT_LIMIT = { limit: 10, windowMs: 10 * 60_000 };
const notFound = () => new DomainError(404, "COMMENT_NOT_FOUND", "That comment no longer exists.");

/**
 * Comments on Explore posts (D-031): any signed-in member, visible at once ("post-moderation").
 * Hidden automatically after COMMENT_REPORT_THRESHOLD reports, or by the post's managers / Super-Admins.
 */
@Injectable()
export class CommentsService {
  private readonly limiter: RateLimiter;

  constructor(
    @Inject(DB) private readonly db: Database,
    private readonly explore: ExploreService,
    private readonly access: ExploreAccess,
    private readonly audit: AuditService,
    @Inject(RATE_LIMIT_STORE) store: RateLimitStore,
  ) {
    this.limiter = new RateLimiter(store);
  }

  async list(postId: string, viewer: Principal | undefined): Promise<{ items: Comment[] }> {
    const post = await this.explore.approved(postId);
    const actor = viewer ? await this.access.actor(viewer) : null;
    const moderator = actor ? canModerateComment(actor, post) : false;
    const rows = await this.db
      .select({ c: postComments, f: members.firstName, l: members.lastName })
      .from(postComments)
      .innerJoin(members, eq(members.id, postComments.memberId))
      .where(eq(postComments.postId, postId))
      .orderBy(asc(postComments.createdAt))
      .limit(500);
    const me = viewer?.kind === "member" ? viewer.id : null;
    return {
      items: rows
        // Hidden comments stay visible to the moderators and to the person who wrote them.
        .filter((r) => r.c.status === "VISIBLE" || moderator || r.c.memberId === me)
        .map((r) => ({
          id: r.c.id,
          author: { name: `${r.f} ${r.l}`, isMe: r.c.memberId === me },
          body: r.c.body,
          status: r.c.status,
          createdAt: r.c.createdAt.toISOString(),
          canDelete: r.c.memberId === me,
          canModerate: moderator,
        })),
    };
  }

  async add(memberId: string, postId: string, body: string, _ip: string) {
    await this.explore.approved(postId);
    await this.limiter.consume([{ key: `comment:member:${memberId}`, ...COMMENT_LIMIT }]);
    await this.db.insert(postComments).values({ postId, memberId, body });
    return this.list(postId, { kind: "member", id: memberId });
  }

  private async comment(id: string) {
    const [row] = await this.db
      .select({ c: postComments, post: posts })
      .from(postComments)
      .innerJoin(posts, eq(posts.id, postComments.postId))
      .where(eq(postComments.id, id))
      .limit(1);
    if (!row) throw notFound();
    return row;
  }

  async remove(memberId: string, id: string) {
    const { c } = await this.comment(id);
    if (c.memberId !== memberId) throw new DomainError(403, "NOT_ALLOWED", "You can only delete your own comments.");
    await this.db.delete(postComments).where(eq(postComments.id, id));
  }

  /** One report per person; the comment hides itself at the threshold until reviewed. */
  async report(memberId: string, id: string, ip: string) {
    const { c } = await this.comment(id);
    if (c.memberId === memberId) return;
    const added = await this.db.insert(commentReports).values({ commentId: id, memberId }).onConflictDoNothing().returning();
    if (!added.length) return;
    const [next] = await this.db
      .update(postComments)
      .set({
        reportCount: sql`${postComments.reportCount} + 1`,
        status: sql`case when ${postComments.reportCount} + 1 >= ${COMMENT_REPORT_THRESHOLD} then 'HIDDEN'::comment_status_enum else ${postComments.status} end`,
      })
      .where(eq(postComments.id, id))
      .returning();
    if (next?.status === "HIDDEN" && c.status === "VISIBLE")
      await this.audit.write({ actorType: "SYSTEM", action: "explore.comment_auto_hidden", entityType: "comment", entityId: id, metadata: { reports: next.reportCount }, ip });
  }

  async setStatus(p: Principal, id: string, status: CommentStatus, ip: string) {
    const { c, post } = await this.comment(id);
    const actor = await this.access.actor(p);
    if (!canModerateComment(actor, post)) throw new DomainError(403, "NOT_ALLOWED", "Only the post's managers can hide comments.");
    // Restoring clears the reports, so the same reports can't hide it again.
    await this.db.update(postComments).set({ status, ...(status === "VISIBLE" ? { reportCount: 0 } : {}) }).where(eq(postComments.id, id));
    if (status === "VISIBLE") await this.db.delete(commentReports).where(eq(commentReports.commentId, id));
    await this.audit.write({
      actorType: actor.kind === "user" ? "USER" : "MEMBER",
      actorId: actor.id,
      groupId: post.churchId,
      action: status === "HIDDEN" ? "explore.comment_hidden" : "explore.comment_restored",
      entityType: "comment",
      entityId: c.id,
      ip,
    });
  }

  /** Super-Admin: comments with reports, most reported first. */
  async reported() {
    const rows = await this.db
      .select({ c: postComments, f: members.firstName, l: members.lastName, title: posts.title })
      .from(postComments)
      .innerJoin(members, eq(members.id, postComments.memberId))
      .innerJoin(posts, eq(posts.id, postComments.postId))
      .where(gt(postComments.reportCount, 0))
      .orderBy(desc(postComments.reportCount), desc(postComments.createdAt))
      .limit(200);
    return {
      items: rows.map((r) => ({
        id: r.c.id,
        body: r.c.body,
        status: r.c.status,
        author: `${r.f} ${r.l}`,
        reports: r.c.reportCount,
        post: { id: r.c.postId, title: r.title },
        createdAt: r.c.createdAt.toISOString(),
      })),
    };
  }
}

