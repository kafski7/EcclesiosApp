import type { Comment } from "@ecclesios/shared";
import { COMMENT_MAX, parseLesson, youTubeEmbedUrl } from "@ecclesios/shared/domain";
import { ArrowLeft, Church, ExternalLink, MapPin } from "lucide-react";
import { useMemo, useState, type FormEvent } from "react";
import { Link, useParams } from "react-router-dom";
import { Lesson } from "@/components/teachings/lesson";
import { ApiClientError } from "@/lib/api";
import { authErrorMessage } from "@/lib/auth-errors";
import { dateBox, eventWhen, KIND_LABEL, useCommentActions, useComments, usePost } from "@/lib/explore";
import { useSession } from "@/stores/session";

/** One Explore post with its comments (D-031). */
export function ExplorePostPage() {
  const { id } = useParams();
  const post = usePost(id);
  const blocks = useMemo(() => parseLesson(post.data?.body ?? ""), [post.data?.body]);
  if (post.isPending) return <p className="muted small">Loading…</p>;
  if (post.isError)
    return (
      <p className="card rail-card">
        {post.error instanceof ApiClientError && post.error.code === "POST_NOT_FOUND" ? "We couldn't find that post." : "This post could not be loaded."}
      </p>
    );
  const p = post.data;

  return (
    <div className="content-narrow mx-auto">
      <Link to="/explore" className="link mb-4">
        <ArrowLeft className="ic" aria-hidden /> Explore
      </Link>
      <article className="card post-page-head">
        <span className={`x-tag${p.kind === "EVENT" ? " x-tag--gold" : ""}`}>{KIND_LABEL[p.kind]}</span>
        <h1>{p.title}</h1>
        <p className="small muted flex items-center gap-2">
          {p.author.kind === "CHURCH" ? (
            <Link to={`/explore/churches/${p.author.id}`} className="link">
              <Church className="ic" aria-hidden /> {p.author.name}
            </Link>
          ) : (
            p.author.name
          )}
          {p.publishedAt ? ` · ${new Date(p.publishedAt).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })}` : ""}
        </p>
        {p.event ? (
          <div className="event-box">
            <span className="date-box" aria-hidden>
              <b>{dateBox(p.event.startsAt).day}</b>
              <small>{dateBox(p.event.startsAt).month}</small>
            </span>
            <div className="meta">
              <b>{eventWhen(p.event.startsAt, p.event.endsAt)}</b>
              <span className="flex items-center gap-1">
                <MapPin className="ic" style={{ width: 14, height: 14 }} aria-hidden /> {p.event.place}
              </span>
              {p.event.onlineUrl ? (
                <a href={p.event.onlineUrl} target="_blank" rel="noopener noreferrer" className="link">
                  Join online <ExternalLink className="ic" aria-hidden />
                </a>
              ) : null}
            </div>
          </div>
        ) : null}
        {p.coverUrl ? <img src={p.coverUrl} alt="" className="post-cover" /> : null}
        {p.summary ? <p className="mt-4" style={{ fontSize: 16, color: "var(--text-2)" }}>{p.summary}</p> : null}
        {p.youtubeId ? (
          <div className="yt-frame mt-4">
            <iframe src={youTubeEmbedUrl(p.youtubeId)} title={p.title} loading="lazy" allow="accelerometer; encrypted-media; gyroscope; picture-in-picture" allowFullScreen />
          </div>
        ) : null}
        <div className="mt-4">
          <Lesson blocks={blocks} />
        </div>
      </article>
      <Comments postId={p.id} />
    </div>
  );
}

function Comments({ postId }: { postId: string }) {
  const principal = useSession((s) => s.principal);
  const list = useComments(postId);
  const act = useCommentActions(postId);
  const [body, setBody] = useState("");
  const [reported, setReported] = useState<string[]>([]);
  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (body.trim()) act.add.mutate(body.trim(), { onSuccess: () => setBody("") });
  };
  const items = list.data?.items ?? [];

  return (
    <section className="card rail-card mt-4" aria-label="Comments">
      <h2 className="rail-title mb-3">Comments{items.length ? ` (${items.filter((c) => c.status === "VISIBLE").length})` : ""}</h2>
      {principal?.kind === "member" ? (
        <form onSubmit={submit} className="mb-4">
          <textarea
            className="field-input"
            style={{ minHeight: 80, fontFamily: "inherit" }}
            maxLength={COMMENT_MAX}
            placeholder="Add a respectful comment"
            aria-label="Your comment"
            value={body}
            onChange={(e) => setBody(e.target.value)}
          />
          {act.add.error ? (
            <p className="small mt-1" style={{ color: "var(--danger)" }}>
              {authErrorMessage(act.add.error instanceof ApiClientError ? act.add.error : null)}
            </p>
          ) : null}
          <button type="submit" className="btn btn-primary btn-sm mt-2" disabled={act.add.isPending || !body.trim()}>
            {act.add.isPending ? "Posting…" : "Comment"}
          </button>
        </form>
      ) : !principal ? (
        <p className="small muted mb-3">
          <Link to="/login" className="link">Sign in</Link> to join the conversation.
        </p>
      ) : null}
      {list.isPending ? <p className="small muted">Loading…</p> : null}
      {list.isSuccess && !items.length ? <p className="small muted">No comments yet.</p> : null}
      <ul className="comments">
        {items.map((c) => (
          <CommentRow
            key={c.id}
            c={c}
            reported={reported.includes(c.id)}
            canReport={principal?.kind === "member" && !c.author.isMe}
            onDelete={() => confirm("Delete your comment?") && act.remove.mutate(c.id)}
            onReport={() => act.report.mutate(c.id, { onSuccess: () => setReported((r) => [...r, c.id]) })}
            onToggle={() => act.setStatus.mutate({ id: c.id, status: c.status === "VISIBLE" ? "HIDDEN" : "VISIBLE" })}
          />
        ))}
      </ul>
    </section>
  );
}

function CommentRow(props: {
  c: Comment;
  reported: boolean;
  canReport: boolean;
  onDelete: () => void;
  onReport: () => void;
  onToggle: () => void;
}) {
  const { c } = props;
  return (
    <li style={c.status === "HIDDEN" ? { opacity: 0.6 } : undefined}>
      <span className="avatar av-32 av-slate" aria-hidden>
        {c.author.name.split(" ").map((x) => x[0]).slice(0, 2).join("")}
      </span>
      <div className="min-w-0 flex-1">
        <b className="small">{c.author.name}</b>{" "}
        <span className="small muted">{new Date(c.createdAt).toLocaleDateString(undefined, { day: "numeric", month: "short" })}</span>
        {c.status === "HIDDEN" ? <div className="hidden-note">Hidden</div> : null}
        <p className="small" style={{ whiteSpace: "pre-line", color: "var(--text-2)" }}>{c.body}</p>
        <div className="comment-actions">
          {c.canDelete ? <button type="button" onClick={props.onDelete}>Delete</button> : null}
          {c.canModerate ? <button type="button" onClick={props.onToggle}>{c.status === "VISIBLE" ? "Hide" : "Show again"}</button> : null}
          {props.canReport ? (
            props.reported ? <span className="muted">Reported — thank you</span> : <button type="button" onClick={props.onReport}>Report</button>
          ) : null}
        </div>
      </div>
    </li>
  );
}
