import type { PostSummary } from "@ecclesios/shared";
import { BookOpen, CalendarDays, MessageCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { dateBox, eventWhen, KIND_LABEL } from "@/lib/explore";

/** Kit x-card (docs/ecclesios-ui Explore). */
export function PostCard({ p }: { p: PostSummary }) {
  return (
    <Link to={`/explore/posts/${p.id}`} className="card x-card">
      <div className="x-media">
        {p.coverUrl ? (
          <img src={p.coverUrl} alt="" loading="lazy" />
        ) : p.youtubeId ? (
          <img src={`https://i.ytimg.com/vi/${p.youtubeId}/hqdefault.jpg`} alt="" loading="lazy" />
        ) : p.kind === "EVENT" ? (
          <CalendarDays className="ic" aria-hidden />
        ) : (
          <BookOpen className="ic" aria-hidden />
        )}
      </div>
      <div className="x-body">
        <span className={`x-tag${p.kind === "EVENT" ? " x-tag--gold" : ""}`}>{KIND_LABEL[p.kind]}</span>
        <h3 className="x-title">{p.title}</h3>
        {p.event ? (
          <div className="flex items-center gap-3">
            <span className="date-box" aria-hidden>
              <b>{dateBox(p.event.startsAt).day}</b>
              <small>{dateBox(p.event.startsAt).month}</small>
            </span>
            <span className="x-meta">
              {eventWhen(p.event.startsAt, p.event.endsAt)}
              <br />
              {p.event.place}
            </span>
          </div>
        ) : p.summary ? (
          <p className="x-meta">{p.summary}</p>
        ) : null}
        <span className="x-meta mt-auto flex items-center gap-2 pt-2">
          {p.author.name}
          {p.commentCount ? (
            <>
              {" · "}
              <MessageCircle className="ic" style={{ width: 13, height: 13 }} aria-hidden /> {p.commentCount}
            </>
          ) : null}
        </span>
      </div>
    </Link>
  );
}
