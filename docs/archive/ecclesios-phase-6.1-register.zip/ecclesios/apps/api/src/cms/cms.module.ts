import { Module } from "@nestjs/common";
import { RbacModule } from "../rbac/rbac.module";
import { CmsController } from "./cms.controller";
import { CmsService } from "./cms.service";
import { RegisterController } from "./register.controller";
import { RegisterService } from "./register.service";

/** Church Management (functionality §4): contexts, dashboard, register and birthdays (Phase 6.1). */
@Module({
  imports: [RbacModule],
  controllers: [CmsController, RegisterController],
  providers: [CmsService, RegisterService],
})
export class CmsModule {}
