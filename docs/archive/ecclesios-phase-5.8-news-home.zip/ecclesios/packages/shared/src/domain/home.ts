/**
 * Home (functionality §3.1, D-033): hymn of the day, trending posts and the blended feed.
 * Pure and deterministic, so every server and every test agrees on "today's" picks.
 */
import { liturgicalDay, type LiturgicalSeason } from "./liturgy.js";

// ------------------------------------------------------------------ hymn of the day

/** Season → the hymnal tag that belongs to it (D-026 tags). Ordinary Time has none. */
export const SEASON_TAG: Record<LiturgicalSeason, string | null> = {
  ADVENT: "advent",
  CHRISTMAS: "christmas",
  LENT: "lent",
  TRIDUUM: "lent",
  EASTER: "easter",
  ORDINARY: null,
};
const SEASONAL_TAGS = new Set(["advent", "christmas", "lent", "easter"]);

/** Small, stable string hash (FNV-1a) — same result on every machine. */
export function stableHash(s: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

export interface HymnCandidate {
  slug: string;
  tags: readonly string[];
}

/**
 * Hymn of the day for a date: a hymn of the current season if there is one; in Ordinary Time,
 * any hymn that is NOT purely seasonal (no Christmas carols in July). Picks by date hash, so it
 * changes daily and is the same for everyone. `pinned` (a Super-Admin choice) wins.
 */
export function hymnOfDay<T extends HymnCandidate>(all: readonly T[], date: string, pinned?: string | null): T | null {
  if (pinned) {
    const p = all.find((h) => h.slug === pinned);
    if (p) return p;
  }
  const tag = SEASON_TAG[liturgicalDay(date).season];
  const seasonal = tag ? all.filter((h) => h.tags.includes(tag)) : [];
  const ordinary = all.filter((h) => !h.tags.some((t) => SEASONAL_TAGS.has(t)));
  const pool = (seasonal.length ? seasonal : ordinary.length ? ordinary : all)
    .slice()
    .sort((a, b) => a.slug.localeCompare(b.slug));
  if (!pool.length) return null;
  return pool[stableHash(date) % pool.length]!;
}

// ------------------------------------------------------------------ trending

export const TRENDING_WINDOW_DAYS = 14;
export const TRENDING_ACTIVITY_HOURS = 72;

/**
 * Trending score (Hacker-News style): recent comments push a post up, age pulls it down.
 * score = (recentComments × 3 + 1) / (hoursSincePublished + 2)^1.2
 * Gentler gravity than HN (1.8) because a parish community is small: a post with a few
 * comments yesterday should still beat one nobody has answered yet.
 */
export function trendingScore(recentComments: number, publishedAt: Date, now: Date): number {
  const hours = Math.max(0, (now.getTime() - publishedAt.getTime()) / 3_600_000);
  return (recentComments * 3 + 1) / Math.pow(hours + 2, 1.2);
}

export function rankTrending<T extends { id: string; publishedAt: Date; recentComments: number }>(
  rows: readonly T[],
  now: Date,
  limit = 5,
): T[] {
  const cutoff = now.getTime() - TRENDING_WINDOW_DAYS * 86_400_000;
  return rows
    .filter((r) => r.publishedAt.getTime() >= cutoff && r.publishedAt <= now)
    .map((r) => ({ r, s: trendingScore(r.recentComments, r.publishedAt, now) }))
    .sort((a, b) => b.s - a.s || b.r.publishedAt.getTime() - a.r.publishedAt.getTime() || a.r.id.localeCompare(b.r.id))
    .slice(0, limit)
    .map((x) => x.r);
}

// ------------------------------------------------------------------ blended feed

export const FEED_ITEM_TYPES = ["POST", "TEACHING", "EPISODE", "NEWS"] as const;
export type FeedItemType = (typeof FEED_ITEM_TYPES)[number];

export interface FeedEntry {
  type: FeedItemType;
  /** Stable id within its type. */
  key: string;
  at: Date;
}

/**
 * Merge per-source lists (each already newest-first) into one page, newest first.
 * Each source must supply at least `page × size` items for the page to be exact.
 */
export function mergeFeed<T extends FeedEntry>(sources: readonly (readonly T[])[], page: number, size: number) {
  const all = sources
    .flat()
    .slice()
    .sort((a, b) => b.at.getTime() - a.at.getTime() || a.type.localeCompare(b.type) || a.key.localeCompare(b.key));
  const start = (page - 1) * size;
  return { items: all.slice(start, start + size), hasMore: all.length > start + size };
}
