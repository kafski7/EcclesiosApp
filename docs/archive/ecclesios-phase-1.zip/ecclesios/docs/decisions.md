# Decision Log

Decisions that change or clarify blueprint.md / functionality.md. Newest first.

| # | Date | Decision | Docs updated |
|---|---|---|---|
| D-004 | 2026-09-30 | `hierarchy.md`, `sup_prompt.md`, `prompt.md` are dropped. The hierarchy is defined in blueprint §3 and functionality §5. | todo |
| D-003 | 2026-09-30 | Two separate role sets: church roles (Administrator, Manager, Society-Leader, Parishioner) on `members`; platform roles (Super-Admin, Creator) on `users`, with creator abilities as explicit privileges. | blueprint §4, §7 · functionality §1 · todo P1 |
| D-002 | 2026-09-30 | Suffragan dioceses are children of the metropolitan archdiocese in the tree. What the archdiocese sees is a per-diocese setting `metropolitan_visibility` = `hidden` / `aggregates` (default) / `detailed`, set by the diocese's own Administrator. Never write access. Province aggregates unaffected. | blueprint §3, §3.4–3.5 · functionality §5.3 · todo P1, P6 |
| D-001 | 2026-09-30 | Outstation collections are staged locally in `pending_collections` (PENDING → APPROVED → SYNCED / REJECTED / SYNC_FAILED) and posted to the external accounting API only after parish approval. | blueprint §7, §8.1 · functionality §4.12 · todo P1, P6 |
